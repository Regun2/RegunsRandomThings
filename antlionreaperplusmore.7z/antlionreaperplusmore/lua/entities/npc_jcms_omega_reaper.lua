-- File: lua/entities/npc_jcms_omega_reaper.lua
-- Omega Antlion Reaper – colossal boss variant for Map Sweepers
-- Octantis Addons © 2025

AddCSLuaFile()

ENT.Type        = "ai"
ENT.Base        = "npc_jcms_reaper"
ENT.PrintName   = "Omega Antlion Reaper"
ENT.Author = "Octantis Addons + Regunkyle + 4o"
ENT.AdminOnly   = false
ENT.RenderGroup = RENDERGROUP_BOTH

list.Set("NPC", "npc_jcms_omega_reaper", {
    Name     = "Omega Antlion Reaper",
    Class    = "npc_jcms_omega_reaper",
    Category = "Reapers N' More"
})

------------------------------------------------------------------
if SERVER then

    ENT.StartHealth        = 5000
    ENT.BeamRange          = 2500
    ENT.BeamDamage         = 120
    ENT.BeamAttackInterval = 1.25   -- increased to fire less often
    ENT.DeathrayCooldown   = 7

    function ENT:Initialize()
        self.BaseClass.Initialize(self)

        self:SetModelScale(4, 0)

	timer.Simple(0, function()
	    if not IsValid(self) then return end
	    local mins = self:OBBMins()
	    self:SetPos(self:GetPos() - Vector(0, 0, mins.z) + Vector(0, 0, 200))
	end)
        self:SetColor(Color(255, 140, 0))
        self:SetMaterial("models/shiny")

        self:SetMaxHealth(self.StartHealth)
        self:SetHealth(self.StartHealth)

        self.CurrentEyeIndex = 0
        self.NextBeamAttack  = CurTime() + self.BeamAttackInterval
        self.NextDeathray    = 0

        -- Spawn entrance effects
        local pos = self:GetPos()
        util.ScreenShake(pos, 25, 150, 1.0, 2048)

        local ball = ents.Create("prop_combine_ball")
        if IsValid(ball) then
            ball:SetPos(pos + Vector(0, 0, 32))
            ball:SetKeyValue("spawnflags", "256")   -- explode instantly
            ball:SetKeyValue("ballradius", "128")  -- shockwave size
            ball:SetKeyValue("exploderadius", "0") -- no damage
            ball:SetKeyValue("explodedamage", "0")
            ball:Spawn()
            ball:Fire("Explode")
            ball:Fire("Kill", "", 0.1)
        end

        self:EmitSound("npc/stalker/stalker_scream1.wav", 140, 90)
    end

    function ENT:GetEyePosition(index)
        local a   = self:EyeAngles()
        local pos = self:WorldSpaceCenter()

        local headId = self:LookupBone("Antlion.Head_Bone")
        if headId and headId > 0 then
            pos, a = self:GetBonePosition(headId)
            a:RotateAroundAxis(a:Forward(), 90)
            a:RotateAroundAxis(a:Right(), 180)
        end

        local offsets = {
            Vector( 32,  0,  18), -- R top
            Vector(-32,  0,  18), -- L top
            Vector( 38,  0,   2), -- R mid
            Vector(-38,  0,   2), -- L mid
            Vector( 44,  0, -14), -- R bottom
            Vector(-44,  0, -14), -- L bottom
        }

        local off = offsets[index]
        if not off then return nil end

        return pos
             + a:Right()   * off.x
             + a:Up()      * off.z
             + a:Forward() * off.y
    end

    function ENT:BeamAttack()
        local enemy = self:GetEnemy()
        if not IsValid(enemy) then return end

        self.CurrentEyeIndex = self.CurrentEyeIndex % 6 + 1
        local eyePos = self:GetEyePosition(self.CurrentEyeIndex)
        if not eyePos then return end

        local targetPos = self:Visible(enemy)
            and (enemy:WorldSpaceCenter() + enemy:GetVelocity() * 0.5)
            or self:GetEnemyLastSeenPos(enemy)

        local dir      = (targetPos - eyePos):GetNormalized()
        local startPos = eyePos + dir * 16

        local beam = ents.Create("jcms_beam")
        if not IsValid(beam) then return end

        beam:SetPos(startPos)
        beam:SetAngles(dir:Angle())
        beam:SetOwner(self)
        beam.IgnoreEntity = self
        beam.Damage        = self.BeamDamage
        beam.BeamWidth     = 48
        beam:SetBeamLength(self.BeamRange)
        beam:Spawn()

        self:EmitSound("ambient/energy/weld" .. math.random(1, 2) .. ".wav", 145, 95)

        beam:FireBeamSweep(
            targetPos,
            (math.random() < 0.5 and math.Rand(0, 0.15) or math.Rand(0.85, 1)),
            ((math.random() < 0.5 and 1 or -1) * math.Rand(10, 20)),
            math.Rand(4, 5)
        )

        if CurTime() > self.NextDeathray and math.random() < 0.3 then
            self:SummonDeathray(targetPos)
            self.NextDeathray = CurTime() + self.DeathrayCooldown
        end
    end

    function ENT:SummonDeathray(pos)
        local dr = ents.Create("jcms_deathray")
        if not IsValid(dr) then return end

        dr:SetPos(pos + Vector(0, 0, 1500))
        dr:SetColor(Color(255,128,0))
        dr:SetOwner(self)
        dr:Spawn()
        dr:Fire("StartBeaming")
        dr:Fire("Kill", "", 6)

        self:EmitSound("ambient/explosions/explode_4.wav", 140, 100)
    end

-- Immunity & filtering ──────────────────────────────────────────
function ENT:OnTakeDamage(dmginfo)
    local attacker = dmginfo:GetAttacker()
    local inflictor = dmginfo:GetInflictor()

    -- Helper to zap & remove a combine ball
    local function ZapBall(ball)
        if not IsValid(ball) then return end

        -- Tesla effect on the ball’s position
        local ed = EffectData()
        ed:SetOrigin(ball:GetPos())
        ed:SetNormal(Vector(0,0,1))
        util.Effect("TeslaHitBoxes", ed, true, true)

        ball:Remove()
    end

    -- 1) If the damage source is a combine ball, zap & destroy it, then ignore
    if IsValid(attacker) and attacker:GetClass() == "prop_combine_ball" then
        ZapBall(attacker)
        return
    end
    if IsValid(inflictor) and inflictor:GetClass() == "prop_combine_ball" then
        ZapBall(inflictor)
        return
    end

    -- 2) Never hurt ourselves or our own beams
    if attacker == self or (IsValid(attacker) and attacker:GetOwner() == self) then
        return
    end

    -- 3) Filter out AR2‐alt fire dissolve damage just in case
    if bit.band(dmginfo:GetDamageType(), DMG_DISSOLVE) ~= 0 then
        return
    end

    -- 4) All other damage applies normally
    self.BaseClass.OnTakeDamage(self, dmginfo)
end



function ENT:Think()
    self.BaseClass.Think(self)

-- Replace this block in ENT:Think or similar update loop
for _, ent in ipairs(ents.FindInSphere(self:GetPos(), 360)) do
    if IsValid(ent) and ent:GetClass() == "prop_combine_ball" then
        -- Detonate the ball with effects
        local effect = EffectData()
        effect:SetOrigin(ent:GetPos())
        util.Effect("cball_explode", effect, true, true)

        ent:EmitSound("NPC_Strider.Shoot") -- or any electric zap
        ent:Remove()
    end
end


    if CurTime() >= (self.NextBeamAttack or 0) then
        self:BeamAttack()
        self.NextBeamAttack = CurTime() + self.BeamAttackInterval
    end

    -- Constantly search for new enemies
    if not IsValid(self:GetEnemy()) then
        self:FindEnemy()
    end

    -- Beam attack logic
    if CurTime() >= (self.NextBeamAttack or 0) and IsValid(self:GetEnemy()) then
        self:BeamAttack()
        self.NextBeamAttack = CurTime() + self.BeamAttackInterval
    end

    self:NextThink(CurTime())
    return true
end

function ENT:FindEnemy()
    local origin        = self:GetPos()
    local radius        = 2500
    local bestTarget    = nil
    local bestDistSqr   = math.huge
    local ignorePlayers = GetConVar("ai_ignoreplayers"):GetBool()

    for _, tgt in ipairs(ents.FindInSphere(origin, radius)) do
        if not IsValid(tgt) or tgt == self then continue end

        -------------------------------------------------
        --   PLAYERS
        -------------------------------------------------
        if tgt:IsPlayer() then
            if ignorePlayers or not tgt:Alive() then continue end
            if self:Visible(tgt) then
                self:SetEnemy(tgt)
                self:UpdateEnemyMemory(tgt, tgt:GetPos())
                return
            end
        -------------------------------------------------
        --   NPCs
        -------------------------------------------------
        elseif tgt:IsNPC() and tgt:Health() > 0 then
            -- never fight clones of ourselves
            if tgt:GetClass() == self:GetClass() then continue end

            local disp = self:Disposition(tgt)   -- our relationship to this NPC
            if disp ~= D_HT then continue end    -- only hate targets!

            -- At this point Antlions that are hostile to us (e.g. zombified) are *allowed*,
            -- while friendly / neutral ones are skipped.

            if self:Visible(tgt) then
                local d2 = origin:DistToSqr(tgt:GetPos())
                if d2 < bestDistSqr then
                    bestTarget  = tgt
                    bestDistSqr = d2
                end
            end
        end
    end

    if IsValid(bestTarget) then
        self:SetEnemy(bestTarget)
        self:UpdateEnemyMemory(bestTarget, bestTarget:GetPos())
    end
end

function ENT:StartTouch(ent)
    if not IsValid(ent) then return end

    if ent:GetClass() == "prop_combine_ball" then
        -- Create Tesla-style disintegration effect
        local effectdata = EffectData()
        effectdata:SetOrigin(ent:GetPos())
        util.Effect("TeslaHitBoxes", effectdata, true, true)

        ent:Fire("Explode")
        ent:Fire("Kill", "", 0.05)

        self:EmitSound("npc/roller/mine/rmine_explode_shock1.wav", 100, 90)
    end
end


    if IsValid(best) then
        self:SetEnemy(best)
        self:UpdateEnemyMemory(best, best:GetPos())
    end

function ENT:AbsorbCombineBall(ball)
    if not IsValid(ball) then return end

    local pos = ball:GetPos()

    -- Tesla effect
    local ed = EffectData()
    ed:SetOrigin(pos)
    ed:SetNormal(Vector(0,0,1))
    util.Effect("TeslaHitBoxes", ed, true, true)

    ball:Remove()

    -- Spawn 6-10 Pellet Fragments
    local count = math.random(6, 10)
    for i = 1, count do
        local frag = ents.Create("jcms_pellet_fragment")
        if not IsValid(frag) then continue end

        frag:SetPos(pos)
        frag:SetAngles(AngleRand())
        frag:SetOwner(self)
        frag:SetVelocity(VectorRand() * math.Rand(200, 500))
        frag:Spawn()
    end

    self:EmitSound("weapons/physcannon/superphys_small_zap1.wav", 90, 120)
end


end -- SERVER

------------------------------------------------------------------
if CLIENT then

    ENT.MatGlow = Material("particle/fire")

    local glowCol  = Color(255,140,0)
    local irisCol  = Color(255,200,0)
    local pupilCol = Color(32,0,0)

    function ENT:DrawEyes()
        local centre = self:WorldSpaceCenter()
        if EyePos():DistToSqr(centre) > 5000^2 then return end

        local a   = self:EyeAngles()
        local pos = centre + a:Forward() * 30

        local headId = self:LookupBone("Antlion.Head_Bone")
        if headId and headId > 0 then
            pos, a = self:GetBonePosition(headId)
            a:RotateAroundAxis(a:Forward(), 90)
            a:RotateAroundAxis(a:Right(), 180)
        end

        local offs = {
            Vector( 32,  0,  18),
            Vector(-32,  0,  18),
            Vector( 38,  0,   2),
            Vector(-38,  0,   2),
            Vector( 44,  0, -14),
            Vector(-44,  0, -14),
        }

        for _, off in ipairs(offs) do
            local ep = pos
                + a:Right()   * off.x
                + a:Up()      * off.z
                + a:Forward() * off.y

            render.SetMaterial(self.MatGlow)
            render.DrawSprite(ep, 96, 72, glowCol)

            render.OverrideDepthEnable(true, true)
            local mat = Matrix()
            mat:Translate(ep)
            mat:Rotate(a)
            cam.PushModelMatrix(mat)
                render.SetColorMaterial()
                render.DrawSphere(vector_origin, 8, 12, 12, irisCol)

                if EyePos():DistToSqr(ep) < 3000^2 then
                    local pm = Matrix()
                    pm:Translate(Vector(6,0,0))
                    pm:Scale(Vector(0.4,0.3,0.7))
                    cam.PushModelMatrix(pm, true)
                        render.DrawSphere(vector_origin, 8, 16, 16, pupilCol)
                    cam.PopModelMatrix()
                end
            cam.PopModelMatrix()
            render.OverrideDepthEnable(false)
        end
    end

    ENT.MatField = Material("models/effects/comball_tape") -- energy-like texture

    function ENT:DrawTranslucent()
        self:DrawModel()
        self:DrawEyes()

        -- Draw Energy Field
        local radius = 360
        cam.Start3D()
            render.SetMaterial(self.MatField)
            render.DrawSphere(self:GetPos(), radius, 24, 24, Color(255, 100, 0, 100))
        cam.End3D()
    end
end

function ENT:SetupDataTables()
    self.BaseClass.SetupDataTables(self)
end
