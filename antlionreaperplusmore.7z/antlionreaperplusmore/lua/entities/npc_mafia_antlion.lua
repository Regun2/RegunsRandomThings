-- Mafia Antlion Entity
AddCSLuaFile()

ENT.Base        = "base_ai"
ENT.Type        = "anim"

ENT.PrintName   = "Mafia Antlion"
ENT.Author      = "Regunkyle + 4o"
ENT.AdminOnly   = false

list.Set("NPC", "npc_mafia_antlion", {
    Name = "Mafia Antlion",
    Class = "npc_mafia_antlion",
    Category = "Reapers N' More"
})

if CLIENT then
    language.Add("npc_mafia_antlion", "Mafia Antlion")
    killicon.Add("npc_mafia_antlion", "HUD/killicons/default", Color(255,255,255,255))
end

if SERVER then

local function GetHeadBoneID(npc)
    return npc:LookupBone("Antlion.Head_Bone") or 0
end

function ENT:SpawnFunction(ply, tr, ClassName)
    if not tr.Hit then return end
    local ent = ents.Create(ClassName)
    ent:SetPos(tr.HitPos + tr.HitNormal * 16)
    ent:SetAngles(Angle(0, ply:EyeAngles().y, 0))
    ent:Spawn()
    ent:Activate()
    return ent
end

function ENT:Initialize()
    self:SetModel("models/antlion.mdl")
    self:SetNoDraw(true)
    self:DrawShadow(false)
    self:DropToFloor()

    self.npc = ents.Create("npc_antlion")
    self.npc:SetPos(self:GetPos())
    self.npc:SetAngles(self:GetAngles())
    self.npc:SetName("Mafia Antlion NPC")
    self.npc:Spawn()
    self.npc:Activate()
    self.npc:SetHealth(80)
    self.npc:SetMaxHealth(80)
    self.npc:SetNWVector("SafeSpot", self.npc:GetPos())
    self:SetParent(self.npc)

    timer.Simple(0, function()
        if not IsValid(self) or not IsValid(self.npc) then return end
        local boneID = GetHeadBoneID(self.npc)

        -- Traffic Cone
        local cone = ents.Create("prop_dynamic")
        if IsValid(cone) then
            cone:SetModel("models/props_junk/TrafficCone001a.mdl")
            cone:SetMoveType(MOVETYPE_NONE)
            cone:SetSolid(SOLID_NONE)
            cone:SetCollisionGroup(COLLISION_GROUP_IN_VEHICLE)
            cone:SetParent(self.npc)
            cone:FollowBone(self.npc, boneID)
            cone:SetLocalPos(Vector(0.00, 21.34, 0.00))
            cone:SetLocalAngles(Angle(0, -11.61, -90.0))
            cone:Spawn()
            self.ConeHat = cone
        end

        -- Thompson Gun
        local gun = ents.Create("prop_dynamic")
        if IsValid(gun) then
            gun:SetModel("models/weapons/w_thompson.mdl")
            gun:SetMoveType(MOVETYPE_NONE)
            gun:SetSolid(SOLID_NONE)
            gun:SetCollisionGroup(COLLISION_GROUP_IN_VEHICLE)
            gun:SetParent(self.npc)
            gun:FollowBone(self.npc, boneID)
            gun:SetLocalPos(Vector(3.92, -7.65, 9.77))
            gun:SetLocalAngles(Angle(0, 165.00, 90.00))
	    gun:SetModelScale(2)
            gun:Spawn()
            self.Gun = gun
        end
    end)

    self.NextShoot = 0
end

function ENT:CanSee(ent)
    local tr = util.TraceLine({
        start  = self.npc:WorldSpaceCenter(),
        endpos = ent:WorldSpaceCenter(),
        filter = {self, self.npc},
        mask   = MASK_SHOT
    })
    return tr.Entity == ent
end

function ENT:ShootGun(enemy)
    if CurTime() < self.NextShoot then return end
    if not (IsValid(self.Gun) and IsValid(enemy)) then return end

    local src = self.Gun:GetPos()
    local dir = (enemy:WorldSpaceCenter() - src):GetNormalized()

    local b = {
        Num        = 1,
        Src        = src,
        Dir        = dir,
        Spread     = Vector(0.03, 0.03, 0),
        Tracer     = 1,
        TracerName = "Tracer",
        Force      = 3,
        Damage     = 3,
        Attacker   = self.npc,
    }

    self.npc:FireBullets(b)
    self.Gun:EmitSound("Weapon_SMG1.Single")
    self.NextShoot = CurTime() + 0.2 -- Fast fire rate
end

function ENT:Think()
    if not IsValid(self) or not IsValid(self.npc) then
        if IsValid(self) then self:Remove() end
        return
    end

    local enemy = self.npc:GetEnemy()
    if IsValid(enemy)
       and self:CanSee(enemy)
       and self.npc:GetPos():Distance(enemy:GetPos()) < 800 then
        self:ShootGun(enemy)
    end

    self:NextThink(CurTime())
    return true
end

function ENT:OnRemove()
    if IsValid(self.npc)     then self.npc:Remove()     end
    if IsValid(self.ConeHat) then self.ConeHat:Remove() end
    if IsValid(self.Gun)     then self.Gun:Remove()     end
end

end -- SERVER
