AddCSLuaFile()

ENT.Type           = "ai"
ENT.Base           = "base_ai"
ENT.PrintName      = "Antlion Reaper Primebane"
ENT.Author         = "Regunkyle + ChatGPT"
ENT.AdminOnly      = false
ENT.RenderGroup    = RENDERGROUP_BOTH

list.Set("NPC", "npc_jcms_reaper_primebane", {
    Name     = "Antlion Reaper Primebane",
    Class    = "npc_jcms_reaper_primebane",
    Category = "Reapers N' More"
})

if SERVER then
    ENT.BeamRange       = 2000
    ENT.NextAttack1Time = 0
    ENT.NextAttack2Time = 0
    ENT.NextPulseTime   = 0
    ENT.Enraged         = false
    ENT.HealthRegenRate = 15

    function ENT:Initialize()
        -- Model setup
        self:SetModel("models/antlion.mdl")
        self:SetMaterial("models/shadertest/shader4")
        self:SetColor(Color(255,40,40))
        self:SetModelScale(1.4, 0)

        -- Hull & collision bounds (approximate antlion, scaled by 1.4)
        self:SetHullType(HULL_LARGE)
        self:SetHullSizeNormal()
        local mins = Vector(-25, -25, 0) * 1.4
        local maxs = Vector( 25,  25, 80) * 1.4
        self:SetCollisionBounds(mins, maxs)

        -- NPC basics
        self:SetMoveType(MOVETYPE_STEP)
        self:SetSolid(SOLID_BBOX)
        self:SetNPCState(NPC_STATE_ALERT)
        self:CapabilitiesAdd(bit.bor(CAP_MOVE_GROUND, CAP_MOVE_JUMP, CAP_TURN_HEAD))
        self:SetUseType(SIMPLE_USE)

        -- Health
        self:SetMaxHealth(130000)
        self:SetHealth(130000)

        -- Movement & AI
        self:SetMaxLookDistance(4000)
        self:SetArrivalSpeed(1100)
        self:SetMaxYawSpeed(200)
        self:SetNavType(NAV_GROUND)
        self:SetNPCClass(CLASS_ANTLION)
        self:SetBloodColor(BLOOD_COLOR_ANTLION)

        -- Timers
        self.NextAttack1Time = CurTime()
        self.NextAttack2Time = CurTime()
        self.NextPulseTime   = CurTime()
        self.LastRegenTime   = CurTime()
    end

    function ENT:OnTakeDamage(dmg)
        -- Apply damage
        local newHealth = math.Clamp(self:Health() - dmg:GetDamage(), 0, self:GetMaxHealth())
        self:SetHealth(newHealth)

        -- Check for enraged phase entry
        if not self.Enraged and (newHealth / self:GetMaxHealth()) <= 0.5 then
            self.Enraged = true
            self:EmitSound("ambient/energy/powerup4.wav", 100, 70)
            -- **Tesla effect** right at phase transition
            local ed = EffectData()
            ed:SetOrigin(self:WorldSpaceCenter())
            ed:SetScale(1)
            util.Effect("Tesla", ed, true, true)
        end

        -- Death handling
        if newHealth <= 0 then
            -- play a death explosion
            local ed2 = EffectData()
            ed2:SetOrigin(self:GetPos())
            util.Effect("Explosion", ed2, true, true)

            -- Emit a loud crack
            self:EmitSound("BaseExplosionEffect.Sound", 120, 100)

            -- Fire the “Kill” input to register in the kill feed
            self:Fire("kill", "", 0)

            return 0
        end

        return 0
    end

    function ENT:Think()
        local e = self:GetEnemy()
        if IsValid(e) then
            self:SetGlarePos(e:EyePos())
            local dist = self:GetPos():Distance(e:GetPos())

            -- Close-range pulse
            if CurTime() > self.NextPulseTime and dist < 300 then
                self:DoPulse()
                self.NextPulseTime = CurTime() + 10
            end

            -- Left/right eye beams
            if CurTime() > self.NextAttack1Time then self:FireEyeBeam(true)  end
            if CurTime() > self.NextAttack2Time then self:FireEyeBeam(false) end
        else
            self:SetGlarePos(vector_origin)
        end

        -- Health regen while enraged
        if self.Enraged and self:Health() < self:GetMaxHealth() then
            local now = CurTime()
            local dt = now - (self.LastRegenTime or now)
            if dt >= 1 then
                self:SetHealth(math.min(self:GetMaxHealth(),
                                       self:Health() + self.HealthRegenRate * dt))
                self.LastRegenTime = now
            end
        end

        self:NextThink(CurTime())
        return true
    end

    function ENT:DoPulse()
        self:EmitSound("ambient/energy/zap9.wav", 100, 100)
        local ed = EffectData()
        ed:SetOrigin(self:GetPos())
        ed:SetRadius(300)
        util.Effect("cball_explode", ed)

        for _, v in ipairs(ents.FindInSphere(self:GetPos(), 300)) do
            if v ~= self and v:IsNPC() and v:Health() > 0 then
                local dmg = DamageInfo()
                dmg:SetAttacker(self)
                dmg:SetInflictor(self)
                dmg:SetDamage(150)
                v:TakeDamageInfo(dmg)
            end
        end
    end

    function ENT:FireEyeBeam(leftEye)
        local bone = self:LookupBone("Antlion.Head_Bone")
        if not bone then return end

        local pos, ang = self:GetBonePosition(bone)
        ang:RotateAroundAxis(ang:Forward(), 90)
        ang:RotateAroundAxis(ang:Right(), 180)
        local offset = ang:Right() * (leftEye and -14 or 14)
                     + ang:Up() * 8
                     + ang:Forward() * -2
        local firePos = pos + offset

        local enemy = self:GetEnemy()
        if not IsValid(enemy) then return end

        local beam = ents.Create("jcms_beam_primebane")
        if not IsValid(beam) then return end

        beam:SetPos(firePos)
        beam:SetBeamAttacker(self)
        beam:Spawn()
        beam.Damage = 10000  -- flat 10000 per hit
        beam:SetBeamLength(self.BeamRange)
        beam:FireBeamSweep(enemy:WorldSpaceCenter(), 0.5, 50, math.Rand(2,3))

        self:EmitSound("ambient/energy/zap"..math.random(1,9)..".wav", 100, 100)

        if leftEye then
            self.NextAttack1Time = CurTime() + (self.Enraged and 1 or 2)
        else
            self.NextAttack2Time = CurTime() + (self.Enraged and 1 or 2)
        end
    end
end

function ENT:SetupDataTables()
    self:NetworkVar("Vector", 0, "GlarePos")
end

if CLIENT then
    ENT.MatGlow = Material("particle/fire")
    ENT.EyePitch = {0,0}
    ENT.EyeYaw   = {0,0}
    ENT.GlowPulse = 0

    function ENT:Think()
        local glare = self:GetGlarePos()
        if not glare or glare == vector_origin then
            glare = self:WorldSpaceCenter() + self:GetForward() * 100
        end

        local dir = (glare - self:WorldSpaceCenter()):Angle() - self:GetAngles()
        for i=1,2 do
            self.EyePitch[i] = Lerp(0.15, self.EyePitch[i], dir.p)
            self.EyeYaw[i]   = Lerp(0.15, self.EyeYaw[i], dir.y)
        end

        -- simple pulsing glow timer
        self.GlowPulse = math.Approach(self.GlowPulse, 1, FrameTime()*2)
        if self.GlowPulse >= 1 then self.GlowPulse = 0 end
    end

	function ENT:DrawEyes()
	    local bone = self:LookupBone("Antlion.Head_Bone")
	    if not bone then return end

	    local pos, ang = self:GetBonePosition(bone)
	    ang:RotateAroundAxis(ang:Forward(), 90)
	    ang:RotateAroundAxis(ang:Right(), 180)

	    for i = 1, 2 do
	        local spacing = (i == 1) and -14 or 14
        local eyep = pos + ang:Right() * spacing + ang:Up() * 8 + ang:Forward() * -2

        -- Eye glow (soft transparent)
	        render.SetMaterial(self.MatGlow)
	        render.DrawSprite(eyep, 40, 40, Color(255, 0, 0, 120))

        -- Eye shell (transparent sphere)
	        render.SetColorMaterial()
	        render.DrawSphere(eyep, 6, 12, 12, Color(255, 0, 0, 120))

        -- Slit pupil
	        render.OverrideDepthEnable(true, true)

	        local pupilOffset = Vector(2, 0, 0)
	        local scale = Vector(0.3, 0.3, 1.5) -- wide & flat for slit effect

	        local mat = Matrix()
	        mat:Translate(eyep)
        mat:Rotate(Angle(ang.p + self.EyePitch[i], ang.y + self.EyeYaw[i], ang.r))
	        mat:Scale(scale)
	        mat:Translate(pupilOffset)

	        cam.PushModelMatrix(mat)
	            render.SetColorMaterial()
	            render.DrawSphere(Vector(0, 0, 0), 3, 8, 8, Color(0, 0, 0, 255))
	        cam.PopModelMatrix()

	        render.OverrideDepthEnable(false)
	    end
	end
    function ENT:DrawTranslucent()
        self:DrawModel()
        self:DrawEyes()
    end
end
