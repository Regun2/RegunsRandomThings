-- enhanced_antlion.lua (combined shared + init)
AddCSLuaFile()

ENT.Base = "base_ai"
ENT.Type = "anim"

ENT.PrintName = "Enhanced Antlion"
ENT.Author = "Dobbi"
ENT.Spawnable = false
ENT.AdminOnly = false

-- Language and killicon setup (client-side)
if CLIENT then
    local Name = "Enhanced Antlion"
    local LangName = "npc_enhanced_antlion"

    language.Add(LangName, Name)
    killicon.Add(LangName, "HUD/killicons/default", Color(0, 0, 0, 255))
    killicon.Add("#"..LangName, "HUD/killicons/default", Color(0, 0, 0, 255))
end

-- Server-side logic
if SERVER then

    function ENT:SpawnFunction(ply, tr)
        if not tr.Hit then return end

        local ent = ents.Create("npc_enhanced_antlion")
        ent:SetPos(tr.HitPos + tr.HitNormal * 10)
        ent:SetAngles(Angle(0, 0, 0))
        ent:Spawn()
        ent:Activate()

        return ent
    end

    function ENT:Initialize()
        self:SetNoDraw(true)
        self:DrawShadow(false)
        self:SetModel("models/antlion.mdl")
        self:DropToFloor()

        self.npc = ents.Create("npc_antlion")
        self.npc:SetPos(self:GetPos())
        self.npc:SetAngles(self:GetAngles())
        self.npc:SetKeyValue("spawnflags", "516")
        self.npc:SetKeyValue("startburrowed", "1")
        self.npc:SetName("Enhanced Antlion")
        self.npc:Spawn()
        self.npc:Activate()
        self:SetParent(self.npc)

        self.npc:SetColor(Color(255, 255, 255, 255))
        self.npc:SetModelScale(1)
        self.npc:SetRenderMode(RENDERMODE_TRANSALPHA)
        self.npc:Fire("Unburrow")
        self.npc:SetHealth(30)
        self.npc:SetMaxHealth(30)
        self.npc:SetNWVector("SafeSpot", self.npc:GetPos())

        self.Initialized = true
    end

    function ENT:Think()
        if IsValid(self) and IsValid(self.npc) then
            local npc = self.npc

            self:SeeEnemyOrNot(npc)
            self:Agitated(npc)
            self:AvoidGuardCharges(npc)
            self:Enemy_Went_In_Water_DONT_ENGAGE(npc)
            self:Relationships(npc)
            self:WanderAbout(npc)
        end
    end

    function ENT:Relationships(npc)
        local relationships = {
            {class = "npc_gman", npc_to_ent = D_ER, ent_to_npc = D_ER},
            {class = "npc_turret_ceiling", npc_to_ent = D_HT, ent_to_npc = D_FR},
            {class = "npc_combinedropship", npc_to_ent = D_HT, ent_to_npc = D_FR},
            {class = "npc_combinegunship", npc_to_ent = D_HT, ent_to_npc = D_FR},
            {class = "npc_helicopter", npc_to_ent = D_HT, ent_to_npc = D_FR},
            {class = "npc_strider", npc_to_ent = D_HT, ent_to_npc = D_FR},
            {class = "npc_breen", npc_to_ent = D_FR, ent_to_npc = D_HT},
            {class = "npc_crow", npc_to_ent = D_FR, ent_to_npc = D_HT},
            {class = "npc_pigeon", npc_to_ent = D_FR, ent_to_npc = D_HT},
            {class = "npc_seagull", npc_to_ent = D_FR, ent_to_npc = D_HT}
        }

        for _, rel in ipairs(relationships) do
            for _, ent in ipairs(ents.FindByClass(rel.class)) do
                if ent:IsNPC() and ent:GetClass() ~= self:GetClass() then
                    ent:AddEntityRelationship(npc, rel.npc_to_ent, 0)
                    npc:AddEntityRelationship(ent, rel.ent_to_npc, 0)
                end
            end
        end
    end

    function ENT:SeeEnemyOrNot(npc)
        self.IHaveEnemy = IsValid(npc:GetEnemy())
    end

    function ENT:Agitated(npc)
        local AgitatedRun = npc:GetSequenceActivity(npc:LookupSequence("RunAgitated"))

        if IsValid(npc) and npc:Health() <= npc:GetMaxHealth() * 0.25 and npc:Health() > 0 and self.IHaveEnemy then
            npc:SetMovementActivity(AgitatedRun)
        end
    end

    function ENT:Enemy_Went_In_Water_DONT_ENGAGE(npc)
        if IsValid(npc) and npc:WaterLevel() < 1 and not self.UpdatedSafeSpot then
            self.UpdatedSafeSpot = true
            npc:SetNWVector("SafeSpot", npc:GetPos())

            timer.Simple(15, function()
                if IsValid(npc) then
                    self.UpdatedSafeSpot = false
                end
            end)
        end

        if IsValid(npc) and IsValid(npc:GetEnemy()) and not self.IHaveEnemy and npc:GetEnemy():WaterLevel() >= 1 then
            npc:RememberUnreachable(npc:GetEnemy(), 10)
        end

        if npc:WaterLevel() == 1 and not npc:IsCurrentSchedule(SCHED_FORCED_GO_RUN) and not self.BackingOutOfWater then
            self.BackingOutOfWater = true
            npc:SetLastPosition(npc:GetNWVector("SafeSpot"))
            npc:SetSchedule(SCHED_FORCED_GO_RUN)

            timer.Simple(3, function()
                if IsValid(npc) then
                    self.BackingOutOfWater = false
                end
            end)
        end
    end

    function ENT:AvoidGuardCharges(npc)
        for _, Fellow_Guard in pairs(ents.FindByClass("npc_antlionguard")) do
            local avoid_moves = {
                [Fellow_Guard:LookupSequence("charge_loop")] = true,
                [Fellow_Guard:LookupSequence("run1")] = true,
            }

            if IsValid(npc) and IsValid(Fellow_Guard) then
                if avoid_moves[Fellow_Guard:GetSequence()] and Fellow_Guard:GetName() ~= "Antlion Royal Guard"
                        and npc:GetPos():DistToSqr(Fellow_Guard:GetPos()) <= (300 ^ 2)
                        and not npc:IsCurrentSchedule(SCHED_FORCED_GO_RUN) then

                    npc:SetLastPosition(npc:GetPos() + npc:GetForward() * -400 + npc:GetRight(math.random(-600, 600)))
                    npc:SetSchedule(SCHED_FORCED_GO_RUN)
                end
            end
        end
    end

    function ENT:WanderAbout(npc)
        if IsValid(npc)
                and not self.IHaveEnemy
                and GetConVar("antlions_patrol"):GetInt() == 1
                and not npc:IsCurrentSchedule(SCHED_FORCED_GO)
                and not npc:IsCurrentSchedule(SCHED_FORCED_GO_RUN)
                and not npc:IsCurrentSchedule(SCHED_PATROL_WALK)
                and not npc:IsCurrentSchedule(SCHED_NPC_FREEZE)
                and not npc:IsCurrentSchedule(SCHED_STANDOFF)
                and self.Initialized
                and npc:WaterLevel() == 0
                and math.random(1, 20) == 3 then

            npc:SetSchedule(SCHED_PATROL_WALK)
        end
    end

    function ENT:OnRemove()
        if IsValid(self.npc) then
            self.npc:Remove()
        end
    end
end
