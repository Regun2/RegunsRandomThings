--[[-------------------------------------------------------------
    Map Sweepers - Co‑op NPC Shooter Gamemode for Garry's Mod
    Damaging Beam Entity
-----------------------------------------------------------------]]
AddCSLuaFile()

---------------------------------------------------------------------
--  Fallback team check logic
---------------------------------------------------------------------
jcms = jcms or {}

if jcms.team_SameTeam == nil then
    function jcms.team_SameTeam(ent1, ent2)
        if not (IsValid(ent1) and IsValid(ent2)) then return false end
        if ent1.Disposition then
            local disp = ent1:Disposition(ent2)
            return disp == D_LI or disp == D_NU
        end
        return false
    end
end

ENT.Type            = "anim"
ENT.Base            = "base_anim"
ENT.PrintName       = "Damaging Beam"
ENT.Author          = "Octantis Addons"
ENT.Category        = "Map Sweepers"
ENT.Spawnable       = false
ENT.RenderGroup     = RENDERGROUP_TRANSLUCENT
ENT.Damage          = 8


-----------------------------------------------------------------
--  >>> NEW: universal SameTeam fallback  <<<
-----------------------------------------------------------------
jcms = jcms or {}

if jcms.team_SameTeam == nil then
    function jcms.team_SameTeam(ent1, ent2)
        if not (IsValid(ent1) and IsValid(ent2)) then return false end

        if ent1:IsPlayer() and ent2:IsPlayer() then
            return ent1:Team() == ent2:Team()
        elseif ent1:IsNPC() and ent2:IsNPC() then
            return ent1:GetNPCClass() == ent2:GetNPCClass()
        end
        return false
    end
end
-----------------------------------------------------------------


function ENT:Initialize()
    if SERVER then
        self:DrawShadow(false)
        self.DamagedEntities  = {}
        self.friendlyFireCutoff = math.huge
    end

    if CLIENT then
        self.BeamColor       = Color(255,200,0)
        self.BeamColorInner  = Color(255,200,0)
    end
end

-----------------------------------------------------------------
--  SERVER‑SIDE
-----------------------------------------------------------------
if SERVER then

    function ENT:FireBeam(fromAngle, toAngle, overTime)
        self:SetBeamTime(0)
        self:SetBeamLifeTime(overTime or 1)
        self:SetBeamFromAngle(fromAngle)
        self:SetBeamToAngle(toAngle)
    end

    function ENT:FireBeamSweep(targetVector, sweepVerticality, sweepDistance, overTime)
        self:SetBeamTime(0)
        self:SetBeamLifeTime(overTime or 1)

        local norm = (targetVector - self:GetPos()):GetNormalized()
        local ang  = norm:Angle()

        local dAng1, dAng2 = Angle(ang), Angle(ang)
        local up, right    = ang:Up(), ang:Right()

        dAng1:RotateAroundAxis(right,  Lerp(sweepVerticality, 0,  sweepDistance))
        dAng2:RotateAroundAxis(right,  Lerp(sweepVerticality, 0, -sweepDistance))
        dAng1:RotateAroundAxis(up,     Lerp(sweepVerticality,  sweepDistance, 0))
        dAng2:RotateAroundAxis(up,     Lerp(sweepVerticality, -sweepDistance, 0))

        self:SetBeamFromAngle(dAng1)
        self:SetBeamToAngle(dAng2)
    end

    function ENT:DealBeamDamage()
        local tr = self:GetBeamTrace()
        if not (IsValid(tr.Entity) and tr.Entity:Health() > 0) then return end
        if self.DamagedEntities[tr.Entity] then return end

        self.DamagedEntities[tr.Entity] = true

        local dmg = DamageInfo()
        dmg:SetDamage(self.Damage)
        dmg:SetInflictor(self)
        dmg:SetReportedPosition(self:GetPos())
        dmg:SetDamageType(DMG_ENERGYBEAM)

        local attacker = self:GetBeamAttacker()
        if IsValid(attacker) then
            dmg:SetAttacker(attacker)
            if jcms.team_SameTeam(attacker, tr.Entity)       -- uses our fallback
               and tr.Entity:GetMaxHealth() > self.friendlyFireCutoff then
                return  -- skip friendly‑fire on “tough” allies
            end
        end

        tr.Entity:DispatchTraceAttack(dmg, tr)
        EmitSound("ambient/levels/citadel/weapon_disintegrate"..math.random(2,3)..".wav",
                  tr.HitPos, 0, CHAN_AUTO, 1, 75, 0, 150)

        if tr.Entity:IsPlayer() then
            tr.Entity:ViewPunch( Angle(math.Rand(-2, 2), math.Rand(-2, 2), 0) )
        end
    end

    function ENT:Think()
        local iv = 1/15
        self:SetBeamTime(self:GetBeamTime() + iv)

        if self:GetBeamTime() >= self:GetBeamLifeTime() then
            self:Remove()
        else
            self:DealBeamDamage()
        end

        self:NextThink(CurTime() + iv)
        return true
    end
end


-----------------------------------------------------------------
--  CLIENT‑SIDE
-----------------------------------------------------------------
if CLIENT then
    ENT.MatBeam = Material("sprites/physgbeamb.vmt")
    ENT.MatGlow = Material("particle/Particle_Glow_04")

    function ENT:DrawTranslucent()
        local frac = math.Clamp(self:GetBeamTime() / self:GetBeamLifeTime(), 0, 1)
        if frac >= 1 then return end

        render.SetMaterial(self.MatBeam)
        render.OverrideBlend(true, BLEND_SRC_ALPHA, BLEND_ONE, BLENDFUNC_ADD)

        local tr     = self.tr or self:GetBeamTrace()
        self.tr      = tr
        local start  = self.StartPosOverride or tr.StartPos
        local len    = tr.HitPos:Distance(start) / 64
        local scroll = math.random()
        local wm     = math.max(0, -4*frac*frac + 4*frac)

        local colOut = self.BeamColor
        local colIn  = self.BeamColorInner
        colIn.r, colIn.g, colIn.b = Lerp(wm, colOut.r, 255), Lerp(wm, colOut.g, 255), Lerp(wm, colOut.b, 255)
        colIn.a                    = wm*wm*255

        render.DrawBeam(start, tr.HitPos, math.Rand(10,12)*wm,
                        scroll*len, (scroll+1)*len, colOut)
        if EyePos():DistToSqr(self:WorldSpaceCenter()) < 1500^2 then
            render.DrawBeam(start, tr.HitPos, math.Rand(3,4)*wm,
                            scroll*len, (scroll+1)*len, colIn)
        end

        if EyePos():DistToSqr(tr.HitPos) < 2500^2 then
            render.SetMaterial(self.MatGlow)
            render.DrawQuadEasy(tr.HitPos, tr.HitNormal, 64*wm, 64*wm, colOut, frac*360)
            render.DrawSprite(tr.HitPos, 64*wm, 24*wm, colIn)
        end
        render.OverrideBlend(false)
    end

    function ENT:Think()
        self.tr = self:GetBeamTrace()
        self:SetBeamTime(self:GetBeamTime() + FrameTime())
        self:SetRenderBoundsWS(self.tr.StartPos, self.tr.HitPos)
        self:SetNextClientThink(CurTime() + 1/66)
        return true
    end
end


-----------------------------------------------------------------
function ENT:GetBeamTrace()
    local frac   = math.Clamp(self:GetBeamTime() / self:GetBeamLifeTime(), 0, 1)
    local normal = LerpAngle(frac, self:GetBeamFromAngle(), self:GetBeamToAngle()):Forward()
    normal:Mul(self:GetBeamLength())

    return util.TraceLine{
        start  = self:GetPos(),
        endpos = self:GetPos() + normal,
        mask   = MASK_SHOT,
        filter = self:GetBeamAttacker()
    }
end

function ENT:SetupDataTables()
    self:NetworkVar("Float",  0, "BeamTime")
    self:NetworkVar("Float",  1, "BeamLifeTime")
    self:NetworkVar("Float",  2, "BeamLength")
    self:NetworkVar("Angle",  0, "BeamFromAngle")
    self:NetworkVar("Angle",  1, "BeamToAngle")
    self:NetworkVar("Entity", 0, "BeamAttacker")

    if SERVER then
        self:SetBeamLifeTime(1)
    end
end
