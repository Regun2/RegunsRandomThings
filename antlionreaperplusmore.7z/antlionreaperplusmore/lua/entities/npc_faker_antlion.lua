AddCSLuaFile()

ENT.Base        = "base_ai"
ENT.Type        = "anim"
ENT.PrintName   = "Antlion..?"
ENT.Author      = "Dobbi + Regunkyle + 4o"
ENT.AdminOnly   = false

list.Set("NPC", "npc_faker_antlion", {
    Name = "Antlion..?",
    Class = "npc_faker_antlion",
    Category = "Reapers N' More"
})

if CLIENT then
    language.Add("npc_faker_antlion", "Antlion..?")
    killicon.Add("npc_faker_antlion", "HUD/killicons/default", Color(255,180,0))
end

if SERVER then

    local TRANSFORM_SOUND    = "npc/antlion/antlion_idle1.wav"
    local TRANSFORM_EFFECT   = "ThumperDust"
    local TRUE_MELEE_DAMAGE  = 25
    local FAKE_COLOR         = Color(120, 120, 120, 255)  -- darker tint
    local TRUE_COLOR         = Color(255, 255, 255, 255)  -- normal

    function ENT:SpawnFunction(ply, tr)
        if not tr.Hit then return end
        local ent = ents.Create("npc_faker_antlion")
        ent:SetPos(tr.HitPos + tr.HitNormal * 10)
        ent:Spawn()
        ent:Activate()
        return ent
    end

    function ENT:Initialize()
        self:SetNoDraw(true)
        self:DrawShadow(false)
        self:SetModel("models/antlion.mdl")
        self:DropToFloor()

        self.Transformed = false

        -- spawn the real antlion
        self.npc = ents.Create("npc_antlion")
        self.npc:SetPos(self:GetPos())
        self.npc:SetAngles(self:GetAngles())
        self.npc:SetKeyValue("spawnflags", "516")
        self.npc:Spawn()
        self.npc:Activate()
        self:SetParent(self.npc)

        -- DARKER fake form color
        self.npc:SetColor(FAKE_COLOR)
        self.npc:SetRenderMode(RENDERMODE_NORMAL)

        self.npc:SetHealth(80)
        self.npc:SetMaxHealth(80)
        self.npc:SetNWVector("SafeSpot", self.npc:GetPos())

        self:StartThinkLoop()
    end

    function ENT:StartThinkLoop()
        timer.Create("FakerAntlionThink_"..self:EntIndex(), 0.25, 0, function()
            if not IsValid(self) or not IsValid(self.npc) then return end
            self:Think()
        end)
    end

    function ENT:Think()
        local npc = self.npc
        if not IsValid(npc) then return end

        if not self.Transformed and npc:Health() <= npc:GetMaxHealth() * 0.3 then
            self:Transform()
        end

        self:HandleWaterExit(npc)

        if self.Transformed then
            self:AlertNearbyZombies(npc)
        end
    end

function ENT:Transform()
    local npc = self.npc
    if not IsValid(npc) then return end
    if self.Transformed then return end
    self.Transformed = true

    -- 0) Heal to double base health
    local baseHP = npc:GetMaxHealth() or 80
    local newMax = baseHP * 2
    npc:SetMaxHealth(newMax)
    npc:SetHealth(newMax)

    -- 1) VFX
    local fx = EffectData()
    fx:SetOrigin(npc:GetPos() + Vector(0,0,10))
    util.Effect("ThumperDust", fx, true, true)

    -- 2) SFX
    npc:EmitSound("npc/antlion/antlion_idle1.wav", 90, 100)

    -- 3) Angry-run animation
    local seq = npc:LookupSequence("RunAgitated")
    if seq and seq > 0 then
        npc:ResetSequence(seq)
    end

    -- 4) Restore color
    npc:SetColor(Color(255,255,255,255))

    -- 5) Scale & material
    npc:SetModelScale(1.25, 1)
    npc:SetMaterial("models/zombie_fast_players/fast_zombie_sheet")

    -- 6) Damage boost
    npc:SetKeyValue("meleedamage", "25")

    -- 7) Relationships (zombies vs everyone else)
    timer.Simple(0.2, function()
        if not IsValid(npc) then return end
        for _, ent in ipairs(ents.GetAll()) do
            if not IsValid(ent) or ent == npc then continue end
            if ent:IsNPC() then
                local c = ent:GetClass()
                local isZ = c:find("zombie") or c:find("headcrab")
                if isZ then
                    npc:AddEntityRelationship(ent, D_LI, 99)
                    ent:AddEntityRelationship(npc, D_LI, 99)
                else
                    npc:AddEntityRelationship(ent, D_HT, 99)
                    ent:AddEntityRelationship(npc, D_HT, 99)
                end
            elseif ent:IsPlayer() then
                npc:AddEntityRelationship(ent, D_HT, 99)
            end
        end
    end)

    -- 8) Wake up angry
    npc:SetSchedule(SCHED_WAKE_ANGRY)
end

    function ENT:AlertNearbyZombies(npc)
        local enemy = npc:GetEnemy()
        if not IsValid(enemy) then return end

        for _, z in ipairs(ents.FindInSphere(npc:GetPos(), 1200)) do
            if z:IsNPC()
               and string.find(z:GetClass(), "zombie")
               and not IsValid(z:GetEnemy())
            then
                z:SetEnemy(enemy)
                z:UpdateEnemyMemory(enemy, enemy:GetPos())
            end
        end
    end

    function ENT:HandleWaterExit(npc)
        if npc:WaterLevel() == 0 and not self.UpdatedSafe then
            self.UpdatedSafe = true
            npc:SetNWVector("SafeSpot", npc:GetPos())
            timer.Simple(15, function() if IsValid(npc) then self.UpdatedSafe = false end end)
        end

        if IsValid(npc:GetEnemy()) and npc:GetEnemy():WaterLevel() >= 1 then
            npc:RememberUnreachable(npc:GetEnemy(), 10)
        end

        if npc:WaterLevel() == 1 and not npc:IsCurrentSchedule(SCHED_FORCED_GO_RUN) and not self.BackingOut then
            self.BackingOut = true
            npc:SetLastPosition(npc:GetNWVector("SafeSpot"))
            npc:SetSchedule(SCHED_FORCED_GO_RUN)
            timer.Simple(3, function() if IsValid(npc) then self.BackingOut = false end end)
        end
    end

    function ENT:OnRemove()
        if IsValid(self.npc) then self.npc:Remove() end
        timer.Remove("FakerAntlionThink_"..self:EntIndex())
    end

end