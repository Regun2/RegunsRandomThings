-- lua/entities/npc_jcms_reaper_ultima.lua
AddCSLuaFile()

DEFINE_BASECLASS("npc_jcms_reaper")

ENT.Type      = "ai"
ENT.Base      = "npc_jcms_reaper"
ENT.PrintName = "Ultima Antlion Reaper"
ENT.Category  = "Map Sweepers"

list.Set("NPC", "npc_jcms_reaper_ultima", {
    Name     = "Ultima Antlion Reaper",
    Class    = "npc_jcms_reaper_ultima",
    Category = "Map Sweepers"
})

----------------------------------------------------------------
-- ░░  S E R V E R
----------------------------------------------------------------
if SERVER then
    function ENT:Initialize()
        BaseClass.Initialize(self)

        self:SetModelScale(3.0, 0)
        self:SetColor(Color(90, 40, 255))
        self:SetMaterial("models/effects/comball_sphere")   -- shiny purple‑blue
        self:SetMaxHealth(2000)
        self:SetHealth(2000)

        self.BeamRange       = 2200
        self.UltBeamDamage   = 120
        self.UltBeamDelay    = 3.5         -- seconds
        self.UltNumBeams     = 4           -- one per eye
    end

    function ENT:BeamAttack()
        local enemy = self:GetEnemy()
        if not IsValid(enemy) or not self:Visible(enemy) then return end

        local centre = self:WorldSpaceCenter()
        local tgtPos = enemy:WorldSpaceCenter()

        self.Beams = self.Beams or {}

        for i = 1, self.UltNumBeams do
            local beam = ents.Create("jcms_beam")
            beam:SetPos(centre)
            beam:SetBeamAttacker(self)
            beam:Spawn()

            beam.Damage = self.UltBeamDamage
            beam:SetBeamLength(self.BeamRange)
            beam:SetKeyValue("rendercolor", "90 40 255")  -- purple

            local sweep   = (i - (self.UltNumBeams + 1) / 2) * 48
            beam:FireBeamSweep(tgtPos, math.Rand(0.3, 0.6), sweep, 3.2)

            self.Beams[i] = beam
        end

        self.NextAttack1Time = CurTime() + self.UltBeamDelay
        self:EmitSound("ambient/levels/labs/electric_explosion2.wav", 145, 90)
    end
end

----------------------------------------------------------------
-- ░░  C L I E N T
----------------------------------------------------------------
if CLIENT then
    ENT.NumEyes        = 4               -- big front eyes
    ENT.EyeSize        = 6               -- radius, bigger than default
    ENT.MatGlow        = Material("sprites/light_glow02_add")

    ENT.EyePitch       = {0,0,0,0}
    ENT.EyeYaw         = {0,0,0,0}
    ENT.EyePitchTarget = {0,0,0,0}
    ENT.EyeYawTarget   = {0,0,0,0}

        local eyeCol = Color(255, 230, 0)
        local eyeGlowCol = Color(255, 200, 0)
        local eyePupilCol = Color(32, 0, 0)

    -- simple tracking, similar to Alpha
    function ENT:Think()
        local head = self:WorldSpaceCenter()
        local look = self:GetGlarePos()
        local see  = head:DistToSqr(look) > 32*32
        local ang  = see and (look - head):Angle() - self:GetAngles() or Angle(0,0,0)

        for i = 1, self.NumEyes do
            if math.random() < (see and 0.5 or 0.02) then
                self.EyePitchTarget[i] = see and ang.p or math.Rand(-30,30)
                self.EyeYawTarget[i]   = see and ang.y or math.Rand(-40,40)
            end

            local s = FrameTime()*600
            self.EyePitch[i] = math.ApproachAngle(self.EyePitch[i], self.EyePitchTarget[i], s)
            self.EyeYaw[i]   = math.ApproachAngle(self.EyeYaw[i],   self.EyeYawTarget[i],   s)
        end
    end

    function ENT:DrawEyes()
        local dist2 = EyePos():DistToSqr(self:WorldSpaceCenter())
        if dist2 > 4000^2 then return end

        local headId = self:LookupBone("Antlion.Head_Bone")
        local headPos, headAng = self:GetBonePosition(headId or 0)
        if not headPos then headPos, headAng = self:WorldSpaceCenter(), self:GetAngles() end

        -- four eyes in a square
        local offsets = {
            Vector(28,  14, 14),    -- TL
            Vector(28, -14, 14),    -- TR
            Vector(28,  14,  0),    -- BL
            Vector(28, -14,  0)     -- BR
        }

        for i = 1, self.NumEyes do
            local lp  = offsets[i]
            local pos = headPos + headAng:Right()  * lp.y
                               + headAng:Forward() * lp.x
                               + headAng:Up()      * lp.z

            render.SetMaterial(self.MatGlow)
            render.DrawSprite(pos, 60, 60, glowCol)

            render.OverrideDepthEnable(true, true)
                local m = Matrix()
                m:Translate(pos)
                m:Rotate(Angle(headAng.p + self.EyePitch[i],
                                headAng.y + self.EyeYaw[i],
                                headAng.r))
                cam.PushModelMatrix(m)
                    render.SetColorMaterial()
                    render.DrawSphere(vector_origin, self.EyeSize, 11, 11, eyeCol)
                cam.PopModelMatrix()
            render.OverrideDepthEnable(false)

            -- attach Ultima beams
            local b = self.Beams
            if istable(b) and IsValid(b[i]) then
                b[i].StartPosOverride = pos
            end
        end
    end

    function ENT:DrawTranslucent()
        self:DrawModel()
        self:DrawEyes()
    end
end
