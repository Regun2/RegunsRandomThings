AddCSLuaFile()

SWEP.Base = "weapon_terminatorfists_term"
DEFINE_BASECLASS(SWEP.Base)

SWEP.PrintName = "HIM Killer"
SWEP.Spawnable = false
SWEP.AdminSpawnable = false
SWEP.Category = "Terminator"
SWEP.Author = "YOU"
SWEP.Purpose = "Used by HIM Hater to destroy HIM."

-- Visuals
SWEP.ViewModel = ""
SWEP.WorldModel = "" -- Don't rely on this

-- No unnecessary stuff
SWEP.UseHands = false
SWEP.DrawAmmo = false

-- Not usable by player
SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = true
SWEP.Primary.Ammo = "none"

-- 💀 Massive damage
SWEP.TERMINATOR_WEAPON_MELEE_DAMAGE = 2147483647
SWEP.TERMINATOR_WEAPON_RANGE = 75
SWEP.TERMINATOR_WEAPON_MINS = Vector(-10, -10, -10)
SWEP.TERMINATOR_WEAPON_MAXS = Vector(10, 10, 10)

-- Create and attach visible hook model
function SWEP:Equip(owner)
    if CLIENT then return end
    timer.Simple(0, function()
        if not IsValid(self) or not IsValid(owner) then return end
        if IsValid(self.HookModel) then self.HookModel:Remove() end

        local hook = ents.Create("prop_dynamic")
        if not IsValid(hook) then return end

        hook:SetModel("models/props_junk/meathook001a.mdl")
        hook:SetPos(owner:GetPos())
        hook:SetAngles(owner:GetAngles())
        hook:SetParent(owner)
        hook:SetOwner(owner)
        hook:Spawn()

        -- Attach to right hand bone if possible
        local boneIndex = owner:LookupBone("ValveBiped.Bip01_R_Hand") or 0
        if boneIndex > 0 then
            hook:FollowBone(owner, boneIndex)
            hook:SetLocalPos(Vector(7, -1, -5)) -- Tune this position
            hook:SetLocalAngles(Angle(0, 90, 0))
        else
            hook:SetParent(owner)
        end

        self.HookModel = hook
    end)
end

-- Cleanup when dropped/removed
function SWEP:OnRemove()
    if IsValid(self.HookModel) then
        self.HookModel:Remove()
    end
end

-- Prevent usage by players
function SWEP:PrimaryAttack() end
function SWEP:SecondaryAttack() end
function SWEP:Reload() end
function SWEP:Think() end

function SWEP:Deploy()
    self:SetHoldType("melee")
    return true
end

function SWEP:HoldTypeThink()
    self:SetHoldType("melee")
end