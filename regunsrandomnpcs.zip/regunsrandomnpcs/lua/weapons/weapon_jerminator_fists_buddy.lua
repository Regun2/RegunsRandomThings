AddCSLuaFile()

SWEP.Base = "weapon_terminatorfists_term"
DEFINE_BASECLASS(SWEP.Base)

SWEP.PrintName = "Jerminator Fists (Friendly)"
SWEP.Spawnable = false
SWEP.Author = "StrawWagen"
SWEP.Purpose = "Used for JermaBuddy. Visual only. No combat."

local className = "weapon_jerminator_fists_buddy"
if CLIENT then
    language.Add(className, SWEP.PrintName)
    killicon.Add(className, "vgui/hud/killicon/weapon_jerminator_fists.png", color_white)
end

-- Disable all attacks
function SWEP:PrimaryAttack() return end
function SWEP:SecondaryAttack() return end
function SWEP:Think() return end
function SWEP:Reload() return end

-- Idle animation only
function SWEP:Deploy()
    self:SetHoldType("normal")
    if SERVER then
        self:ResetSequenceInfo()
        self:SendWeaponAnim(ACT_VM_IDLE)
    end
    return true
end

-- Prevent holdtype changes
function SWEP:HoldTypeThink()
    self:SetHoldType("normal")
end