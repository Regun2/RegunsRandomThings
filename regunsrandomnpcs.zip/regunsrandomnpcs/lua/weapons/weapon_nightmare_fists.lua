AddCSLuaFile()

SWEP.Base = "weapon_terminatorfists_term"
DEFINE_BASECLASS(SWEP.Base)

SWEP.PrintName = "Nightmare Fists"
SWEP.Spawnable = false
SWEP.AdminOnly = false
SWEP.UseHands = false
SWEP.ViewModel = ""
SWEP.WorldModel = ""
SWEP.Author = "System"

SWEP.Primary.Automatic = true
SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Ammo = "none"

-- No damage needed; just a fired weapon logic
SWEP.TERMINATOR_WEAPON_MELEE_DAMAGE = 0
SWEP.TERMINATOR_WEAPON_RANGE = 75
SWEP.TERMINATOR_WEAPON_MINS = Vector(-10, -10, -10)
SWEP.TERMINATOR_WEAPON_MAXS = Vector(10, 10, 10)

function SWEP:PrimaryAttack()
    if CLIENT then return end

    local owner = self:GetOwner()
    if not IsValid(owner) then return end

    local start = owner:EyePos()
    local dir = owner:GetAimVector()

    local tr = util.TraceHull({
        start = start,
        endpos = start + dir * self.TERMINATOR_WEAPON_RANGE,
        filter = owner,
        mins = self.TERMINATOR_WEAPON_MINS,
        maxs = self.TERMINATOR_WEAPON_MAXS,
        mask = MASK_SHOT
    })

    if tr.Hit and IsValid(tr.Entity) then
        local target = tr.Entity

        if target ~= owner and not target.EXA_TRUE then
            if target:IsPlayer() and target:Alive() then
                target:Kill()
            elseif target:IsNPC() or target:IsNextBot() then
                target:SetHealth(0)
                target:TakeDamage(9999999, owner, self)
            elseif target:GetClass():StartWith("prop_") or target:IsVehicle() then
                SafeRemoveEntity(target)
            end

            if isfunction(owner.Disintegrate) then
                owner:Disintegrate()
            end
        end
    end

    self:SetNextPrimaryFire(CurTime() + 1)
end