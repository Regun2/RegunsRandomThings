AddCSLuaFile()

SWEP.Base = "weapon_terminatorfists_term"
DEFINE_BASECLASS(SWEP.Base)

SWEP.PrintName = "Madman Axe"
SWEP.Spawnable = false
SWEP.AdminOnly = false
SWEP.Category = "Terminator Custom"

SWEP.ViewModel = ""
SWEP.WorldModel = "" -- Model is spawned manually

SWEP.UseHands = false
SWEP.DrawAmmo = false

SWEP.Primary.Automatic = true
SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Ammo = "none"

SWEP.TERMINATOR_WEAPON_MELEE_DAMAGE = 85
SWEP.TERMINATOR_WEAPON_RANGE = 75
SWEP.TERMINATOR_WEAPON_MINS = Vector(-10, -10, -10)
SWEP.TERMINATOR_WEAPON_MAXS = Vector(10, 10, 10)

function SWEP:PrimaryAttack()
    if CLIENT then return end

    local owner = self:GetOwner()
    if not IsValid(owner) then return end

    local start = owner:EyePos()
    local forward = owner:GetAimVector()

    local tr = util.TraceHull({
        start = start,
        endpos = start + forward * self.TERMINATOR_WEAPON_RANGE,
        filter = owner,
        mins = self.TERMINATOR_WEAPON_MINS,
        maxs = self.TERMINATOR_WEAPON_MAXS,
        mask = MASK_SHOT
    })

    if tr.Hit and IsValid(tr.Entity) then
        local dmg = DamageInfo()
        dmg:SetDamage(self.TERMINATOR_WEAPON_MELEE_DAMAGE)
        dmg:SetDamageType(DMG_SLASH)
        dmg:SetAttacker(owner)
        dmg:SetInflictor(self)
        tr.Entity:TakeDamageInfo(dmg)

        self:EmitSound("npc/antlion_guard/shove1.wav", 90)
    else
        self:EmitSound("Weapon_Crowbar.Single", 80)
    end

    self:SetNextPrimaryFire(CurTime() + 1.0)
end

function SWEP:Deploy()
    self:SetHoldType("melee")
    return true
end

function SWEP:HoldTypeThink()
    self:SetHoldType("melee")
end

function SWEP:SecondaryAttack() end
function SWEP:Reload() end
function SWEP:Think() end