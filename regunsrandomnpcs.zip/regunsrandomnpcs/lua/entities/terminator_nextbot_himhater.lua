AddCSLuaFile()

ENT.Base = "terminator_nextbot"
DEFINE_BASECLASS(ENT.Base)

ENT.PrintName = "HIM Hater"
ENT.Spawnable = false
ENT.AutomaticFrameAdvance = true

local WEAPON_CLASS = "weapon_himkiller"
ENT.DefaultWeapon = WEAPON_CLASS

list.Set("NPC", "terminator_nextbot_himhater", {
    Name     = ENT.PrintName,
    Class    = "terminator_nextbot_himhater",
    Category = "Terminator Nextbot",
    AdminOnly = true,
    Weapons  = { WEAPON_CLASS },
})

--------------------------------------------------
-- CLIENT
--------------------------------------------------
if CLIENT then
    language.Add("terminator_nextbot_himhater", ENT.PrintName)
    return
end

--------------------------------------------------
-- Configuration
--------------------------------------------------
ENT.SpawnHealth       = 2147483647
ENT.FistDamageMul     = 1
ENT.ThrowingForceMul  = 1
ENT.WalkSpeed         = 460
ENT.MoveSpeed         = 700
ENT.RunSpeed          = 1100
ENT.AccelerationSpeed = 6000
ENT.JumpHeight        = 120
ENT.TERM_WEAPON_PROFICIENCY = WEAPON_PROFICIENCY_PERFECT
ENT.duelEnemyTimeoutMul = 5

--------------------------------------------------
-- Server
--------------------------------------------------
if SERVER then

    function ENT:AdditionalInitialize()
        self:SetModel("models/player/Group01/male_07.mdl")
        self:SetColor(Color(0, 255, 0))
        self:SetMaterial("")
    end

    function ENT:ShouldRunAI()
        return true
    end

    function ENT:DoHardcodedRelations()
        self.term_HardCodedRelations = {
            ["terminator_nextbot_homeless"] = { D_HT, D_HT, 1000 },
        }
    end

    function ENT:ShouldBeEnemy(ent)
        return IsValid(ent) and ent:GetClass() == "terminator_nextbot_homeless"
    end

    function ENT:OnEntityAngered(ent)
        if IsValid(ent) and ent:GetClass() == "terminator_nextbot_homeless" then
            BaseClass.OnEntityAngered(self, ent)
        end
    end

end