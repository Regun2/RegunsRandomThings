AddCSLuaFile()

ENT.Base = "terminator_nextbot_jerminator"
DEFINE_BASECLASS(ENT.Base)

ENT.PrintName = "Jerma985F"
ENT.Spawnable = false
ENT.BehaveInterval = 0.1

list.Set("NPC", "terminator_nextbot_jerminator_friendly", {
    Name = "Jerma985F",
    Class = "terminator_nextbot_jerminator_friendly",
    Category = "Terminator Nextbot"
})

if CLIENT then
    language.Add("terminator_nextbot_jerminator_friendly", ENT.PrintName)
    return
end

-- CONFIG
local MODEL = "models/player/giwake/jermaregular.mdl"
ENT.Models = { MODEL }
ENT.ARNOLD_MODEL = MODEL

ENT.TERM_FISTS = "weapon_jerminator_fists"
ENT.SpawnHealth = 2000
ENT.FistDamageMul = 1.5
ENT.HealthRegen = 4
ENT.HealthRegenInterval = 0.5

ENT.term_SoundPitchShift = 0
ENT.term_SoundLevelShift = 15

ENT.WalkSpeed = 165
ENT.MoveSpeed = 300
ENT.RunSpeed = 550

function ENT:AdditionalInitialize()
    self:SetModel(self.ARNOLD_MODEL)
    self:SetColor(Color(255, 255, 255))
    self:SetModelScale(1.1, 0)
    self.isTerminatorHunterChummy = "jerminator_friendly"
end

function ENT:DoHardcodedRelations()
    self.term_HardCodedRelations = {
        ["player"] = { D_LI, D_LI, 1000 },
        ["npc_citizen"] = { D_LI, D_LI, 1000 },
        ["exterminator_nextbot"] = { D_LI, D_LI, 1000 },
        ["terminator_nextbot_jerminator_buddy"] = { D_LI, D_LI, 1000 },
    }
end

-- Make npc_citizen friendly back to Jerma
hook.Add("OnEntityCreated", "Jerma985F_CitizenFriendly", function(ent)
    if ent:IsNPC() and ent:GetClass() == "npc_citizen" then
        timer.Simple(0, function()
            for _, jerma in ipairs(ents.FindByClass("terminator_nextbot_jerminator_friendly")) do
                if IsValid(jerma) then
                    ent:AddEntityRelationship(jerma, D_LI, 99)
                end
            end
        end)
    end
end)