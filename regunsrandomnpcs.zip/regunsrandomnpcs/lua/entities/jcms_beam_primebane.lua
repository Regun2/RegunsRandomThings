AddCSLuaFile()

ENT.Type        = "anim"
ENT.Base        = "base_anim"
ENT.PrintName   = "Primebane Beam"
ENT.Spawnable   = false
ENT.RenderGroup = RENDERGROUP_TRANSLUCENT
ENT.AdminOnly   = true
ENT.Damage      = 10000

function ENT:Initialize()
    if SERVER then
        self.DamagedEntities = {}
    else
        self.BeamColor      = Color(255,0,0)
        self.BeamColorInner = Color(255,80,80)
    end
end

if SERVER then
    function ENT:FireBeamSweep(target, vert, dist, life)
        self:SetBeamTime(0)
        self:SetBeamLifeTime(life or 1)
        local norm = (target - self:GetPos()):GetNormalized()
        local ang  = norm:Angle()
        local d1, d2 = Angle(ang), Angle(ang)
        local up, rt = ang:Up(), ang:Right()
        d1:RotateAroundAxis(rt,  Lerp(vert, 0,  dist))
        d2:RotateAroundAxis(rt,  Lerp(vert, 0, -dist))
        d1:RotateAroundAxis(up,   Lerp(vert,  dist, 0))
        d2:RotateAroundAxis(up,   Lerp(vert, -dist, 0))
        self:SetBeamFromAngle(d1)
        self:SetBeamToAngle(d2)
    end

    function ENT:DealBeamDamage()
        local tr = self:GetBeamTrace()
        if not (IsValid(tr.Entity) and tr.Entity:Health()>0) then return end
        if self.DamagedEntities[tr.Entity] then return end
        self.DamagedEntities[tr.Entity] = true

        local dmg = DamageInfo()
        local attacker = self:GetBeamAttacker()
        if IsValid(attacker) then
            dmg:SetAttacker(attacker)
        else
            dmg:SetAttacker(self)
        end
        dmg:SetInflictor(self)
        dmg:SetDamage(self.Damage)
        dmg:SetDamageType(DMG_ENERGYBEAM)
        tr.Entity:TakeDamageInfo(dmg)
    end

    function ENT:Think()
        self:SetBeamTime(self:GetBeamTime() + 1/20)
        if self:GetBeamTime() >= self:GetBeamLifeTime() then
            self:Remove()
        else
            self:DealBeamDamage()
        end
        self:NextThink(CurTime() + 1/20)
        return true
    end
end

if CLIENT then
    ENT.MatBeam = Material("sprites/physgbeamb.vmt")
    ENT.MatGlow = Material("particle/Particle_Glow_04")

    function ENT:DrawTranslucent()
        local tr    = self:GetBeamTrace()
        local start = self:GetPos()
        local len   = tr.HitPos:Distance(start) / 64
        local frac  = math.Clamp(self:GetBeamTime()/self:GetBeamLifeTime(), 0,1)
        local wm    = math.max(0, -4*frac*frac + 4*frac)

        render.SetMaterial(self.MatBeam)
        render.DrawBeam(start, tr.HitPos, 32*wm, frac*len, (frac+1)*len, self.BeamColor)
        render.DrawBeam(start, tr.HitPos, 12*wm, frac*len, (frac+1)*len, self.BeamColorInner)

        render.SetMaterial(self.MatGlow)
        render.DrawSprite(tr.HitPos, 80*wm, 80*wm, self.BeamColorInner)
    end
end

function ENT:GetBeamTrace()
    local frac   = math.Clamp(self:GetBeamTime()/self:GetBeamLifeTime(), 0,1)
    local normal = LerpAngle(frac, self:GetBeamFromAngle(), self:GetBeamToAngle()):Forward()
    return util.TraceLine({
        start  = self:GetPos(),
        endpos = self:GetPos() + normal * self:GetBeamLength(),
        filter = self:GetBeamAttacker(),
        mask   = MASK_SHOT
    })
end

function ENT:SetupDataTables()
    self:NetworkVar("Float",  0, "BeamTime")
    self:NetworkVar("Float",  1, "BeamLifeTime")
    self:NetworkVar("Float",  2, "BeamLength")
    self:NetworkVar("Angle",  0, "BeamFromAngle")
    self:NetworkVar("Angle",  1, "BeamToAngle")
    self:NetworkVar("Entity", 0, "BeamAttacker")
end
