AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_entity"

function ENT:Initialize()
    if CLIENT then return end

    self:SetModel("models/props_junk/propane_tank001a.mdl")
    self:SetColor(Color(0, 200, 255))
    self:SetMaterial("models/shiny")
    self:SetModelScale(2)
    self:SetMoveType(MOVETYPE_NONE)
    self:SetSolid(SOLID_NONE)

    self.ChargeTime = CurTime() + 3
    self:SetNoDraw(false)

    local glow = ents.Create("env_sprite")
    if IsValid(glow) then
        glow:SetKeyValue("model","sprites/blueglow2.vmt")
        glow:SetKeyValue("scale","1.5")
        glow:SetPos(self:GetPos())
        glow:SetParent(self)
        glow:Spawn()
    end
end

function ENT:Think()
    if CLIENT then return end
    if CurTime() >= self.ChargeTime then
        self:Explode()
    end
end

function ENT:Explode()
    if CLIENT then return end

    local pos = self:GetPos()

    local effectdata = EffectData()
    effectdata:SetOrigin(pos)
    util.Effect("cball_explode", effectdata)

    util.ScreenShake(pos, 10, 2, 2, 500)

    for _, ent in pairs(ents.FindInSphere(pos, 300)) do
        if ent ~= self and ent.TakeDamage then
            local dmg = DamageInfo()
            dmg:SetAttacker(IsValid(self:GetOwner()) and self:GetOwner() or self)
            dmg:SetInflictor(self)
            dmg:SetDamageType(DMG_DISSOLVE)
            dmg:SetDamage(300)
            ent:TakeDamageInfo(dmg)
        end
    end

    self:Remove()
end