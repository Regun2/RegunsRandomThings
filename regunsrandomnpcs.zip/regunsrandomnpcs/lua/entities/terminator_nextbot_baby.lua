AddCSLuaFile()

ENT.Base = "terminator_nextbot"
DEFINE_BASECLASS(ENT.Base)

ENT.PrintName = "Baby Terminator"
ENT.Spawnable = false
ENT.AdminOnly = false

list.Set("NPC", "terminator_nextbot_baby", {
    Name = ENT.PrintName,
    Class = "terminator_nextbot_baby",
    Category = "Terminator Nextbot",
    Weapons = { "weapon_terminatorfists_term" },
})

ENT.DefaultWeapon = "weapon_terminatorfists_term"

ENT.WalkSpeed = 60
ENT.MoveSpeed = 70
ENT.RunSpeed  = 100
ENT.AccelerationSpeed = 250
ENT.JumpHeight = 0
ENT.StepHeight = 20

ENT.FistDamageMul = 0.1
ENT.FistForceMul = 0.2
ENT.ThrowingForceMul = 0.2

ENT.SpawnHealth = 10
ENT.CanFindWeaponsOnTheGround = false
ENT.TERM_WEAPON_PROFICIENCY = WEAPON_PROFICIENCY_POOR
ENT.duelEnemyTimeoutMul = 5

--------------------------------------------------
-- Server
--------------------------------------------------
if SERVER then

    function ENT:AdditionalInitialize()
        self:SetModel(self.Models[1])
        self:SetModelScale(0.4, 0)
        self:SetColor(Color(255, 255, 255))
        self:SetHealth(self.SpawnHealth)
    end

    function ENT:OnInjured(dmgInfo)
        local damage = dmgInfo:GetDamage()
        dmgInfo:SetDamage(damage * 2.5)

        BaseClass.OnInjured(self, dmgInfo)
    end

end

--------------------------------------------------
-- Client
--------------------------------------------------
if CLIENT then
    language.Add("terminator_nextbot_baby", ENT.PrintName)
end