AddCSLuaFile()

ENT.Base = "terminator_nextbot"
DEFINE_BASECLASS(ENT.Base)

ENT.PrintName = "Madman"
ENT.Spawnable = false
ENT.AutomaticFrameAdvance = true

local WEAPON_CLASS = "weapon_headhunter_axe"
ENT.DefaultWeapon = WEAPON_CLASS
ENT.Models = { "models/player/soldier_stripped.mdl" }

list.Set("NPC", "terminator_nextbot_madman", {
    Name     = ENT.PrintName,
    Class    = "terminator_nextbot_madman",
    Category = "Terminator Nextbot",
    Weapons  = { WEAPON_CLASS },
})

--------------------------------------------------
-- CLIENT
--------------------------------------------------
if CLIENT then
    language.Add("terminator_nextbot_madman", ENT.PrintName)
    return
end

--------------------------------------------------
-- Configuration
--------------------------------------------------
ENT.SpawnHealth       = 500
ENT.BaseMaxHealth     = 500

ENT.FistDamageMul     = 1
ENT.ThrowingForceMul  = 1
ENT.WalkSpeed         = 250
ENT.MoveSpeed         = 450
ENT.RunSpeed          = 650
ENT.AccelerationSpeed = 3000
ENT.JumpHeight        = 175
ENT.TERM_WEAPON_PROFICIENCY = WEAPON_PROFICIENCY_PERFECT
ENT.duelEnemyTimeoutMul = 5
ENT.CanFindWeaponsOnTheGround = false

--------------------------------------------------
-- Server
--------------------------------------------------

if SERVER then

    function ENT:AdditionalInitialize()
        self:SetModel(self.Models[1])
        self:SetHealth(self.SpawnHealth)
        self.isTerminatorHunterChummy = "madman"
        self:AttachVisibleAxe()
    end

    function ENT:AttachVisibleAxe()
        if IsValid(self.AxeModel) then return end

        local axe = ents.Create("prop_dynamic")
        if not IsValid(axe) then return end

        axe:SetModel("models/weapons/w_models/w_fireaxe.mdl")
        axe:SetOwner(self)
        axe:SetParent(self)
        axe:Spawn()

        local bone = self:LookupBone("ValveBiped.Bip01_R_Hand") or 0
        if bone > 0 then
            axe:FollowBone(self, bone)
            axe:SetLocalPos(Vector(4, -1, -0))
            axe:SetLocalAngles(Angle(0, 0, 180))
        end

        self.AxeModel = axe
    end

    function ENT:DoHardcodedRelations()
        self.term_HardCodedRelations = {
            ["player"]                   = { D_HT, D_HT, 1000 },
            ["npc_*"]                    = { D_HT, D_HT, 1000 },
            ["terminator_nextbot"]       = { D_HT, D_HT, 1000 },
            ["terminator_nextbot_*"]     = { D_HT, D_HT, 1000 },
            ["prop_physics"]             = { D_HT, D_HT, 1000 },
            ["nextbot"]                  = { D_HT, D_HT, 1000 },
            ["*"]                        = { D_HT, D_HT, 1000 },
        }
    end

end