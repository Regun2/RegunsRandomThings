AddCSLuaFile()

ENT.Type = "ai"
ENT.Base = "npc_jcms_reaper"
ENT.PrintName = "Alpha Antlion Reaper"
ENT.Author = "Regunkyle + 4o"
ENT.AdminOnly = false

list.Set("NPC", "npc_jcms_alpha_reaper", {
    Name = "Alpha Antlion Reaper",
    Class = "npc_jcms_alpha_reaper",
    Category = "Zombies + Enemy Aliens"
})

if SERVER then
    function ENT:Initialize()
        self.BaseClass.Initialize(self)
        self:SetModelScale(1.5, 0)
	self:SetColor(Color(90, 75, 20))
        self:SetMaxHealth(300)
        self:SetHealth(300)
        self.BeamRange = 1500
        self.BeamFireRateMult = 0.25

        -- Track beam timers
        self.NextAttack1Time = 0
        self.NextAttack2Time = 0

        -- Add extended eye tracking data
        self.EyeAnglePitch = {}
        self.EyeAngleYaw = {}
        self.EyeAngleTargetPitch = {}
        self.EyeAngleTargetYaw = {}

        for i = 1, 8 do
            self.EyeAnglePitch[i] = 0
            self.EyeAngleYaw[i] = 0
            self.EyeAngleTargetPitch[i] = 0
            self.EyeAngleTargetYaw[i] = 0
        end
    end
end

if CLIENT then
    ENT.MatGlow = Material("particle/fire")

    -- Eye angle arrays (8 eyes)
    ENT.EyeAnglePitch = {}
    ENT.EyeAngleYaw = {}
    ENT.EyeAngleTargetPitch = {}
    ENT.EyeAngleTargetYaw = {}

    for i = 1, 8 do
        ENT.EyeAnglePitch[i] = 0
        ENT.EyeAngleYaw[i] = 0
        ENT.EyeAngleTargetPitch[i] = 0
        ENT.EyeAngleTargetYaw[i] = 0
    end

    function ENT:Think()
        local glarePos = self:GetGlarePos()
        local selfPos = self:WorldSpaceCenter()
        local lookAtTarget = selfPos:DistToSqr(glarePos) > 32 * 32
        local eyeang = self:EyeAngles()

        if lookAtTarget then
            eyeang = glarePos - selfPos
            eyeang:Normalize()
            eyeang = eyeang:Angle() - self:GetAngles()
        end

        for i = 1, 8 do
            if math.random() < (lookAtTarget and 0.5 or 0.02) then
                self.EyeAngleTargetPitch[i] = lookAtTarget and eyeang.p or math.Rand(-32, 32)
                self.EyeAngleTargetYaw[i] = lookAtTarget and eyeang.y or math.Rand(-48, 48)
            end
        end

        local appr = FrameTime() * 720
        for i = 1, 8 do
            self.EyeAnglePitch[i] = math.ApproachAngle(self.EyeAnglePitch[i] or 0, self.EyeAngleTargetPitch[i] or 0, appr)
            self.EyeAngleYaw[i] = math.ApproachAngle(self.EyeAngleYaw[i] or 0, self.EyeAngleTargetYaw[i] or 0, appr)
        end
    end

    function ENT:DrawEyes(eyeGlowMat)
        local center = self:WorldSpaceCenter()
        local distToPlayer = EyePos():DistToSqr(center)
        if distToPlayer > 3000 ^ 2 then return end

        local a = self:GetAngles()
        local pos = center + a:Forward() * 14

        local headId = self:LookupBone("Antlion.Head_Bone")
        if headId and headId > 0 then
            pos, a = self:GetBonePosition(headId)
            a:RotateAroundAxis(a:Forward(), 90)
            a:RotateAroundAxis(a:Right(), 180)
        end

        local eyeCol = Color(255, 230, 0)
        local eyeGlowCol = Color(255, 200, 0)
        local eyePupilCol = Color(32, 0, 0)
        local eyePupilScale = Vector(0.3, 0.2, 0.6)
        local eyePupilOffset = Vector(3, 0, 0)

        -- 4 normal + 4 high/back eye offsets
        local eyeOffsets = {
            Vector(9, 4, 0), Vector(16, 7, -4),       -- normal
            Vector(9, 12, -8), Vector(16, 15, -10)    -- higher and back
        }

        local eyeId = 0
        for smul = -1, 1, 2 do
            for _, off in ipairs(eyeOffsets) do
                eyeId = eyeId + 1
                local eyepos = pos + a:Right() * smul * off.x + a:Up() * off.y + a:Forward() * off.z
                eyepos:Add(VectorRand(-0.1, 0.1))

                -- Beam origin override
                if eyeId == 2 and self.GetBeam1 then
                    local beam = self:GetBeam1()
                    if IsValid(beam) then beam.StartPosOverride = eyepos end
                elseif eyeId == 8 and self.GetBeam2 then
                    local beam = self:GetBeam2()
                    if IsValid(beam) then beam.StartPosOverride = eyepos end
                end

                if distToPlayer < 1000 ^ 2 then
                    render.SetMaterial(eyeGlowMat or self.MatGlow)
                    render.DrawSprite(eyepos, math.Rand(32, 48), math.Rand(24, 32), eyeGlowCol)
                end

                render.OverrideDepthEnable(true, true)

                local mat = Matrix()
                mat:Translate(eyepos)

                local pitch = self.EyeAnglePitch[eyeId] or 0
                local yaw = self.EyeAngleYaw[eyeId] or 0
                mat:Rotate(Angle(a.p + pitch, a.y + yaw, a.r))

                cam.PushModelMatrix(mat)
                    render.SetColorMaterial()
                    render.DrawSphere(vector_origin, 4, 9, 9, eyeCol)

                    if distToPlayer < 1500 ^ 2 then
                        local mat_pupil = Matrix()
                        mat_pupil:Translate(eyePupilOffset)
                        mat_pupil:Scale(eyePupilScale)
                        cam.PushModelMatrix(mat_pupil, true)
                            render.DrawSphere(vector_origin, 4, 13, 13, eyePupilCol)
                        cam.PopModelMatrix()
                    end
                cam.PopModelMatrix()
                render.OverrideDepthEnable(false)
            end
        end
    end

    function ENT:DrawTranslucent()
        self:DrawModel()
        self:DrawEyes()
    end
end
