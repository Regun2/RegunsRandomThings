-- addons/regunsrandomnpcs/lua/entities/punt_gun.lua
AddCSLuaFile()

-- =========================
-- Projectile entity
-- =========================
local PROJ = {}
PROJ.Type = "anim"
PROJ.Base = "base_anim"
PROJ.PrintName = "Punt Projectile"
PROJ.Spawnable = false

local PROJECTILE_MODEL = "models/Items/AR2_Grenade.mdl"
local TRAIL_MATERIAL = "trails/laser"
local TRAIL_COLOR = Color(255,140,0,255)

function PROJ:Initialize()
  if SERVER then
    self:SetModel(PROJECTILE_MODEL)
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    local phys = self:GetPhysicsObject()
    if IsValid(phys) then phys:Wake() end

    self.LifeEnd = CurTime() + 12
    self:SetCollisionGroup(COLLISION_GROUP_PROJECTILE)

    util.SpriteTrail(self, 0, TRAIL_COLOR, false, 8, 1, 0.15, 1/(8+1)*0.5, TRAIL_MATERIAL)
  end
end

function PROJ:Think()
  if CLIENT then return end
  if self.LifeEnd and CurTime() > self.LifeEnd then SafeRemoveEntity(self); return end

  if self.ProjType == "homing" and IsValid(self.Target) then
    local phys = self:GetPhysicsObject()
    if IsValid(phys) then
      local dir = (self.Target:WorldSpaceCenter() - self:GetPos()):GetNormalized()
      phys:SetVelocity(dir * (self.HomingSpeed or 2400))
    end
  end

  self:NextThink(CurTime() + 0.05)
  return true
end

function PROJ:PhysicsCollide(data, phys)
  if CLIENT then return end

  local hitpos = data.HitPos
  local owner = (IsValid(self.Owner) and self.Owner) or self

  if self.ProjType == "mini" then
    self:Explode(hitpos, 100, 50, owner)
    return
  end

  self:Explode(hitpos, self.ExplosionRadius or 220, self.ExplosionDamage or 160, owner)
end

function PROJ:Explode(pos, radius, damage, attacker)
  if not pos then pos = self:GetPos() end
  local inflictor = self
  if not IsValid(attacker) then attacker = self end

  util.BlastDamage(inflictor, attacker, pos, radius or 220, damage or 160)
  local ed = EffectData(); ed:SetOrigin(pos); util.Effect("Explosion", ed)
  SafeRemoveEntity(self)
end

scripted_ents.Register(PROJ, "punt_projectile")

-- =========================
-- Main punt_gun entity
-- =========================
ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Punt Gun"
ENT.Author = "Regunkyle"
ENT.Category = "Fun + Games"
ENT.Spawnable = true

local SHOTGUN_MODEL = "models/weapons/w_shotgun.mdl"
local DESIRED_FEET = 9
local UNITS_PER_FOOT = 12
local DESIRED_UNITS = DESIRED_FEET * UNITS_PER_FOOT

local MODE_CANNON = 1
local MODE_BUCKSHOT = 2
local MODE_CLUSTER = 3
local MODE_NAMES = {
  [MODE_CANNON]  = "Cannonball",
  [MODE_BUCKSHOT] = "Buckshot",
  [MODE_CLUSTER] = "Cluster",
}

-- Initialize
function ENT:Initialize()
  if SERVER then
    self:SetModel(SHOTGUN_MODEL)
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetUseType(SIMPLE_USE)
    self:SetSolid(SOLID_VPHYSICS)

    local phys = self:GetPhysicsObject()
    if IsValid(phys) then phys:Wake() end

    local mins, maxs = self:OBBMins(), self:OBBMaxs()
    local localLength = math.abs(maxs.x - mins.x)
    local scale = 1
    if localLength > 0 then
      scale = DESIRED_UNITS / localLength
    else
      scale = 3.6
    end
    self.ScaleMultiplier = scale
    self:SetModelScale(scale, 0)

    self.Mode = MODE_CANNON
    self.NextUse = 0
    self.NextFire = 0
  end
end

-- Helper: try multiple attachment names for muzzle
local function GetMuzzleAttachment(ent)
  if not IsValid(ent) then return nil end
  local tries = { "muzzle", "muzzle_flash", "1", "2", "barrel" }
  for _, name in ipairs(tries) do
    local aid = ent:LookupAttachment(name)
    if aid and aid > 0 then
      local att = ent:GetAttachment(aid)
      if att and att.Pos and att.Ang then return att end
    end
  end
  return nil
end

-- Return muzzle pos and direction (gun-forward) — MUST use muzzle attachment when available
function ENT:GetMuzzlePosAndDir()
  local att = GetMuzzleAttachment(self)
  if att then return att.Pos, att.Ang:Forward() end

  -- fallback: estimate from model origin & forward vector using a reasonable offset that respects scale
  local fallbackOffset = Vector(36, 0, 8)
  local pos = self:LocalToWorld(fallbackOffset * (self.ScaleMultiplier or 1))
  local dir = self:GetForward()
  return pos, dir
end

-- Sounds
local function PlayModeSwitchSound(ply)
  if IsValid(ply) then ply:EmitSound("buttons/button14.wav", 80, 120) end
end
local function PlayFireSoundCannon(ply) if IsValid(ply) then ply:EmitSound("weapons/rpg/rocketfire1.wav", 110, 95) end end
local function PlayFireSoundBuck(ply) if IsValid(ply) then ply:EmitSound("weapons/shotgun/shotgun_fire6.wav", 100, 95) end end
local function PlayFireSoundCluster(ply) if IsValid(ply) then ply:EmitSound("weapons/stinger_fire1.wav", 100, 96) end end

-- Fire functions
function ENT:DoFireCannon(ply)
  local pos, dir = self:GetMuzzlePosAndDir()
  if not pos or not dir then return end

  local proj = ents.Create("punt_projectile")
  if not IsValid(proj) then return end
  proj:SetPos(pos + dir * 8)
  proj:SetAngles(dir:Angle())
  proj:Spawn()
  proj.Owner = ply
  proj.ProjType = "cannon"
  proj.ExplosionRadius = 260
  proj.ExplosionDamage = 220
  local phys = proj:GetPhysicsObject()
  if IsValid(phys) then phys:Wake(); phys:SetVelocity(dir * 5200) end

  PlayFireSoundCannon(ply)
end

-- Buckshot (fixed: traces from muzzle — NOT camera)
function ENT:DoFireBuckshot(ply)
  local pos, dir = self:GetMuzzlePosAndDir()
  if not pos or not dir then return end

  local pellets = 24
  local range = 3500
  local dmgPer = 9
  local spread = 0.18 -- tightened spread (more compact but not too tight)

  for i = 1, pellets do
    local rnd = VectorRand() * spread
    local pelletDir = (dir + rnd):GetNormalized()
    local tr = util.TraceLine({
      start = pos,
      endpos = pos + pelletDir * range,
      filter = {self, ply},
      mask = MASK_SHOT
    })

    -- tracer from muzzle to impact/miss end
    local tracerEnd = tr.Hit and tr.HitPos or (pos + pelletDir * range)
    local edt = EffectData()
    edt:SetStart(pos)
    edt:SetOrigin(tracerEnd)
    edt:SetScale(1)
    util.Effect("ToolTracer", edt)

    if tr.Hit then
      local hitEnt = tr.Entity
      if IsValid(hitEnt) then
        local dmg = DamageInfo()
        dmg:SetAttacker(ply)
        dmg:SetInflictor(self)
        dmg:SetDamage(dmgPer)
        dmg:SetDamageType(DMG_BULLET)
        dmg:SetDamagePosition(tr.HitPos)
        hitEnt:TakeDamageInfo(dmg)
      end

      -- use beam-like / spark impact instead of explosion
      local ed = EffectData()
      ed:SetOrigin(tr.HitPos)
      ed:SetNormal(tr.HitNormal)
      util.Effect("manhack_sparks", ed)

      -- apply physics push to hit object if possible
      if IsValid(tr.Entity) then
        local phys = tr.Entity:GetPhysicsObject()
        if IsValid(phys) then phys:ApplyForceCenter(pelletDir * 1500) end
      else
        util.Decal("Impact.Concrete", tr.HitPos + tr.HitNormal * 2, tr.HitPos - tr.HitNormal * 2)
      end
    end
  end

  PlayFireSoundBuck(ply)
end

-- Cluster (spawns small explosive projectiles)
function ENT:DoFireCluster(ply)
  local pos, dir = self:GetMuzzlePosAndDir()
  if not pos or not dir then return end

  local miniCount = 6
  for i = 1, miniCount do
    local proj = ents.Create("punt_projectile")
    if not IsValid(proj) then continue end
    proj:SetPos(pos + dir * 8)
    proj:SetAngles(dir:Angle() + AngleRand() * 0.05)
    proj:Spawn()
    proj.Owner = ply
    proj.ProjType = "mini"
    proj.ExplosionRadius = 120
    proj.ExplosionDamage = 80
    local phys = proj:GetPhysicsObject()
    if IsValid(phys) then
      local spreadDir = (dir + VectorRand() * 0.12):GetNormalized()
      phys:Wake()
      phys:SetVelocity(spreadDir * (2800 + math.random(-300,300)))
    end
  end

  PlayFireSoundCluster(ply)
end

-- Fire wrapper (debounced)
function ENT:FireMode(activator)
  if not IsValid(activator) or CurTime() < (self.NextFire or 0) then return end
  self.NextFire = CurTime() + 0.6

  if self.Mode == MODE_CANNON then
    self:DoFireCannon(activator)
  elseif self.Mode == MODE_BUCKSHOT then
    self:DoFireBuckshot(activator)
  elseif self.Mode == MODE_CLUSTER then
    self:DoFireCluster(activator)
  end
end

-- Player Use: crouch+E cycles mode, E fires (debounced)
function ENT:Use(activator, caller)
  if not IsValid(activator) or not activator:IsPlayer() then return end
  if CurTime() < (self.NextUse or 0) then return end

  if activator:KeyDown(IN_DUCK) or activator:Crouching() then
    self.Mode = (self.Mode or MODE_CANNON) + 1
    if self.Mode > MODE_CLUSTER then self.Mode = MODE_CANNON end
    self.NextUse = CurTime() + 0.45
    PlayModeSwitchSound(activator)
    activator:ChatPrint("Punt Gun mode: " .. (MODE_NAMES[self.Mode] or "Unknown"))
    return
  end

  self:FireMode(activator)
  self.NextUse = CurTime() + 0.15
end

-- Keep phys awake (safe)
function ENT:Think()
  if SERVER then
    local phys = self:GetPhysicsObject()
    if IsValid(phys) then phys:Wake() end -- always safe; avoids IsAwake()/IsAsleep checks
  end
  self:NextThink(CurTime() + 1)
  return true
end

scripted_ents.Register(ENT, "punt_gun")

if CLIENT then
  language.Add("punt_gun", "Punt Gun")
  language.Add("punt_gun_name", "Punt Gun (Cannon / Buckshot / Cluster)")
end
