AddCSLuaFile()

ENT.Base = "terminator_nextbot"
DEFINE_BASECLASS(ENT.Base)

ENT.PrintName = "Ronald McDonald"
ENT.Category = "Terminator Nextbot"
ENT.Spawnable = false

ENT.Models = { "models/mcdonalds/ronald_mcdonald.mdl" }

ENT.SpawnHealth        = 250
ENT.WalkSpeed          = 140
ENT.MoveSpeed          = 180
ENT.RunSpeed           = 320
ENT.AccelerationSpeed  = 2200
ENT.JumpHeight         = 100
ENT.CloseEnemyDistance = 300
ENT.DuelEnemyDist      = 600

ENT.SpecialMoves = {}
ENT.SpecialCooldowns = {}

function ENT:Initialize()
    BaseClass.Initialize(self)

    self:SetModel(self.Models[1])
    self:SetSkin(0)
    self:SetHealth(self.SpawnHealth)

    self:AddSpecialMoves()
    for k in pairs(self.SpecialMoves) do
        self.SpecialCooldowns[k] = 0
    end
end

function ENT:DoCustomTasks(defaultTasks)
    self.TaskList = table.Copy(defaultTasks or {})

    self.TaskList["ronald_handler"] = {
        StartsOnInitialize = true,
        BehaveUpdateMotion = function(self, data)
            local enemy = self:GetEnemy()
            if not IsValid(enemy) then coroutine.yield() return end

            local dist = self:GetPos():Distance(enemy:GetPos())
            for name, move in pairs(self.SpecialMoves) do
                if dist < move.Range and CurTime() > (self.SpecialCooldowns[name] or 0) then
                    move.DoAttack(self, enemy)
                    self.SpecialCooldowns[name] = CurTime() + move.Cooldown
                    break
                end
            end

            coroutine.yield()
        end
    }
end

function ENT:AddSpecialMoves()
    self.SpecialMoves = {

        -- 🍔 BIG MAC BARREL BOMB
        ["BigMac"] = {
            Cooldown = 4,
            Range = 800,
            DoAttack = function(self, enemy)
                local startPos = self:GetShootPos() + Vector(0, 0, 40)
                local aimTarget = enemy:GetPos() + Vector(0, 0, 20) -- aim a little lower
                local direction = (aimTarget - startPos):GetNormalized()

                local burger = ents.Create("prop_physics")
                if not IsValid(burger) then return end
                burger:SetModel("models/food/burger.mdl")
                burger:SetModelScale(3, 0)
                burger:SetPos(startPos + direction * 50)
                burger:SetAngles(direction:Angle())
                burger:SetCollisionGroup(COLLISION_GROUP_PROJECTILE)
                burger:Spawn()

                local phys = burger:GetPhysicsObject()
                if IsValid(phys) then
                    phys:EnableGravity(true)
                    phys:SetVelocity(direction * 3000 + Vector(0, 0, 150))
                end

                -- Orange trail
                util.SpriteTrail(burger, 0, Color(255, 140, 0), false, 32, 8, 0.5, 1 / 40, "trails/laser.vmt")

                -- 💥 Explodes on ANYTHING
                burger:AddCallback("PhysicsCollide", function(ent, data)
                    local explosion = ents.Create("env_explosion")
                    if IsValid(explosion) then
                        explosion:SetPos(ent:GetPos())
                        explosion:SetOwner(self)
                        explosion:SetKeyValue("iMagnitude", "100")
                        explosion:Spawn()
                        explosion:Fire("Explode", "", 0)
                    end
                    ent:Remove()
                end)

                timer.Simple(6, function()
                    if IsValid(burger) then burger:Remove() end
                end)

                self:EmitSound("ronald/bigmac.wav")
            end
        },

        -- 🍟 RAPID BAQUETTE FRIES
        ["FryBarrage"] = {
            Cooldown = 6,
            Range = 600,
            DoAttack = function(self, enemy)
                local start = self:GetShootPos() + Vector(0, 0, 45)
                local dir = (enemy:GetPos() - start):GetNormalized()

                for i = 1, 8 do
                    timer.Simple(i * 0.1, function()
                        if not IsValid(self) or not IsValid(enemy) then return end
                        local fry = ents.Create("prop_physics")
                        if not IsValid(fry) then return end

                        fry:SetModel("models/foodnhouseholditems/bagette.mdl")
                        fry:SetModelScale(0.28)
                        fry:SetMaterial("models/debug/debugwhite")
                        fry:SetColor(Color(255, 255, 0))
                        fry:SetCollisionGroup(COLLISION_GROUP_PROJECTILE)

                        fry:SetPos(start + dir * 35)
                        local ang = dir:Angle()
                        ang:RotateAroundAxis(ang:Right(), -90)
                        fry:SetAngles(ang)
                        fry:Spawn()

                        local phys = fry:GetPhysicsObject()
                        if IsValid(phys) then
                            phys:EnableGravity(false)
                            phys:SetVelocity(dir * 2500)
                        end

                        fry:AddCallback("PhysicsCollide", function(_, data)
                            local hit = data.HitEntity
                            if IsValid(hit) and hit ~= self then
                                local dmg = DamageInfo()
                                dmg:SetAttacker(self)
                                dmg:SetInflictor(fry)
                                dmg:SetDamageType(DMG_CLUB)
                                dmg:SetDamage(15)
                                hit:TakeDamageInfo(dmg)
                                fry:Remove()
                            end
                        end)

                        timer.Simple(4, function()
                            if IsValid(fry) then fry:Remove() end
                        end)
                    end)
                end

                self:EmitSound("ronald/frybarrage.wav")
            end
        },

        -- 🔫 MCLASER
        ["McLaser"] = {
            Cooldown = 15,
            Range = 1500,
            DoAttack = function(self, enemy)
                local start = self:EyePos()
                local target = enemy:EyePos()

                -- Visible yellow tracer
                local effectdata = EffectData()
                effectdata:SetStart(start)
                effectdata:SetOrigin(target)
                effectdata:SetScale(4)
                util.Effect("LaserTracer", effectdata)

                -- Damage
                local tr = util.TraceLine({ start = start, endpos = target, filter = self })
                if IsValid(tr.Entity) and (tr.Entity:IsPlayer() or tr.Entity:IsNPC()) then
                    local dmg = DamageInfo()
                    dmg:SetAttacker(self)
                    dmg:SetInflictor(self)
                    dmg:SetDamage(200)
                    dmg:SetDamageType(DMG_ENERGYBEAM)
                    tr.Entity:TakeDamageInfo(dmg)
                end

                -- Optional: screen shake
                util.ScreenShake(self:GetPos(), 5, 5, 0.3, 500)

                self:EmitSound("ronald/mclaser.wav")
            end
        }
    }
end

function ENT:OnKilled(dmginfo)
    self:EmitSound("ronald/laugh" .. math.random(1, 3) .. ".wav")
    BaseClass.OnKilled(self, dmginfo)
end

if CLIENT then
    language.Add("ronald_nextbot", "Ronald McDonald (MUGEN)")
end

list.Set("NPC", "ronald_nextbot", {
    Name = "Ronald McDonald",
    Class = "ronald_nextbot",
    Category = "Terminator Nextbot"
})