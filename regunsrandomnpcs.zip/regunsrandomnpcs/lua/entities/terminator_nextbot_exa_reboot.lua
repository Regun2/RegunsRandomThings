AddCSLuaFile()

ENT.Base = "terminator_nextbot"
DEFINE_BASECLASS(ENT.Base)

ENT.PrintName = "EXA"
ENT.Spawnable = false
ENT.AutomaticFrameAdvance = true

list.Set("NPC", "terminator_nextbot_exa_reboot", {
    Name = "EXA",
    Class = "terminator_nextbot_exa_reboot",
    Category = "Terminator Nextbot",
    Weapons = { "weapon_terminatorfists_term" },
})

-- Shared configuration
ENT.DefaultWeapon = "weapon_terminatorfists_term"
ENT.Models = { "models/player/combine_super_soldier.mdl" }
ENT.TERM_WEAPON_PROFICIENCY = WEAPON_PROFICIENCY_PERFECT

ENT.WalkSpeed = 90
ENT.MoveSpeed = 225
ENT.RunSpeed  = 400
ENT.AccelerationSpeed = 1800
ENT.JumpHeight = 250
ENT.FistDamageMul = 1.2
ENT.ThrowingForceMul = 1.3

ENT.SpawnHealth = 3000
ENT.BaseMaxHealth = 3000

--------------------------------------------------
-- Server-side Logic
--------------------------------------------------
if SERVER then

    function ENT:AdditionalInitialize()
        self:SetModel(self.Models[1])
        self:SetColor(Color(0, 255, 255))
        self:SetMaterial("models/shiny")
        self:SetHealth(self.SpawnHealth)
        self:SetMaxHealth(self.BaseMaxHealth)
        self:SetNWInt("EXARebootKills", 0)

        self:CreateAuraEffect()
    end

    function ENT:CreateAuraEffect()
        local aura = ents.Create("env_sprite")
        if not IsValid(aura) then return end

        aura:SetKeyValue("model", "sprites/blueflare1.vmt")
        aura:SetKeyValue("scale", "0.6")
        aura:SetKeyValue("rendercolor", "0 255 255")
        aura:SetKeyValue("rendermode", "5")
        aura:SetPos(self:GetPos() + Vector(0, 0, 50))
        aura:SetParent(self)
        aura:Spawn()
        aura:Activate()

        self.Aura = aura
    end

    function ENT:DoHardcodedRelations()
        self.term_HardCodedRelations = {
            ["player"]         = { D_HT, D_HT, 1000 },
            ["npc*"]           = { D_HT, D_HT, 1000 },
            ["nextbot"]        = { D_HT, D_HT, 1000 },
            ["ent_minion_exa"] = { D_LI, D_LI, 1000 },
            ["*"]              = { D_HT, D_HT, 1000 },
        }
    end

    function ENT:DoCustomTasks(defaultTasks)
        self.TaskList = {
            ["exa_reboot_ai"] = {
                StartsOnInitialize = true,
                BehaveUpdatePriority = function(self, data)
                    if not self.NextAbility or CurTime() >= self.NextAbility then
                        self:UseRandomAbility()
                        self.NextAbility = CurTime() + math.Rand(3.5, 6)
                    end
                end,
                OnKillEnemy = function(self, data)
                    self:AddKill()
                end
            }
        }

        table.Merge(self.TaskList, defaultTasks or {})
    end

    function ENT:AddKill()
        local kills = self:GetNWInt("EXARebootKills", 0) + 1
        self:SetNWInt("EXARebootKills", kills)

        -- Visual feedback
        local colorShift = math.Clamp(255 - kills * 10, 0, 255)
        self:SetColor(Color(255, colorShift, 255))

        self:SetMaxHealth(self:GetMaxHealth() + 75)
        self:SetHealth(self:GetMaxHealth())
        self:EmitSound("ambient/levels/labs/electric_explosion2.wav", 95)
        util.ScreenShake(self:GetPos(), 3.5, 1.8, 1.2, 600)
    end

    ---------------------------
    -- Abilities
    ---------------------------
    function ENT:UseRandomAbility()
        local pool = {
            function() self:Ability_SkyBeam() end,
            function() self:Ability_BurstShot() end,
            function() self:Ability_Clone() end,
            function() self:Ability_SpiritBomb() end,
            function() self:Ability_SummonMinions() end,
        }

        local ability = table.Random(pool)
        if ability and isfunction(ability) then
            ability()
        end
    end

    function ENT:Ability_SkyBeam()
        local enemy = self:GetEnemy()
        if not IsValid(enemy) then return end

        local startPos = enemy:GetPos() + Vector(0, 0, 600)
        local endPos = enemy:GetPos()

        local beamFX = EffectData()
        beamFX:SetOrigin(endPos)
        beamFX:SetStart(startPos)
        util.Effect("RPGShotDown", beamFX)

        timer.Simple(0.5, function()
            if not IsValid(self) or not IsValid(enemy) then return end

            local boom = EffectData()
            boom:SetOrigin(endPos)
            util.Effect("HelicopterMegaBomb", boom)

            util.BlastDamage(self, self, endPos, 225, 250)
            enemy:EmitSound("npc/strider/striderbuster_impact1.wav", 95)
        end)

        self:EmitSound("ambient/energy/weld1.wav", 85)
    end

    function ENT:Ability_BurstShot()
        local origin = self:GetPos() + Vector(0, 0, 60)

        for i = 1, 10 do
            local angle = Angle(0, i * (360 / 10), 0)
            local direction = angle:Forward()

            local tr = util.TraceLine({
                start = origin,
                endpos = origin + direction * 700,
                filter = self
            })

            if tr.Hit and IsValid(tr.Entity) and tr.Entity.TakeDamage then
                tr.Entity:TakeDamage(25, self, self)
            end

            local shotFX = EffectData()
            shotFX:SetOrigin(tr.HitPos)
            shotFX:SetStart(origin)
            util.Effect("ToolTracer", shotFX)
        end

        self:EmitSound("weapons/ar2/fire1.wav", 95, 100)
    end

    function ENT:Ability_Clone()
        local pos = self:GetPos() + Vector(0, 0, 60)
        local clone = ents.Create("ent_nightmare_clone")

        if IsValid(clone) then
            clone:SetPos(pos)
            clone:SetAngles(self:GetAngles())
            clone:SetOwner(self)
            clone:Spawn()
            clone:Activate()
            self:EmitSound("ambient/levels/labs/electric_explosion2.wav")
        end
    end

    function ENT:Ability_SpiritBomb()
        local bomb = ents.Create("ent_spiritbomb_exa")
        if IsValid(bomb) then
            bomb:SetPos(self:GetPos() + Vector(0, 0, 60))
            bomb:SetOwner(self)
            bomb:Spawn()
            self:EmitSound("ambient/levels/labs/electric_explosion2.wav")
        end
    end

    function ENT:Ability_SummonMinions()
        for i = 1, 2 do
            timer.Simple(i * 0.25, function()
                if not IsValid(self) then return end

                local offset = Vector(math.random(-100, 100), math.random(-100, 100), 0)
                local minion = ents.Create("ent_minion_exa")

                if IsValid(minion) then
                    minion:SetPos(self:GetPos() + offset)
                    minion:SetAngles(self:GetAngles())
                    minion:SetOwner(self)
                    minion:Spawn()
                    minion:Activate()
                end
            end)
        end

        self:EmitSound("ambient/energy/zap" .. math.random(1, 3) .. ".wav")
    end

    ---------------------------
    -- Death FX
    ---------------------------
    function ENT:OnKilled(_, _, _)
        local pos = self:GetPos()

        local fx = EffectData()
        fx:SetOrigin(pos)
        fx:SetScale(8)
        util.Effect("Explosion", fx)
        util.Effect("HelicopterMegaBomb", fx)

        util.ScreenShake(pos, 100, 4.5, 2.5, 1500)

        self:EmitSound("ambient/levels/labs/teleport_mechanism_winddown1.wav", 130)
        self:EmitSound("ambient/explosions/explode_9.wav", 140)
        self:EmitSound("npc/antlion_guard/antlion_guard_die1.wav", 130)

        SafeRemoveEntity(self)
    end
end

--------------------------------------------------
-- Client Only: Display Kill Count
--------------------------------------------------
if CLIENT then
    language.Add("terminator_nextbot_exa_reboot", "EXA Reboot")

    hook.Add("PostDrawTranslucentRenderables", "EXAReboot_KillCounter", function()
        for _, ent in ipairs(ents.FindByClass("terminator_nextbot_exa_reboot")) do
            if not IsValid(ent) then continue end

            local kills = ent:GetNWInt("EXARebootKills", 0)
            if kills <= 0 then continue end

            local ang = LocalPlayer():EyeAngles()
            local pos = ent:GetPos() + Vector(0, 0, 90)

            cam.Start3D2D(pos, Angle(0, ang.y - 90, 90), 0.25)
                draw.SimpleTextOutlined("KILLS: " .. kills, "DermaLarge", 0, 0, Color(0, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 2, color_black)
            cam.End3D2D()
        end
    end)
end