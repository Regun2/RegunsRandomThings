AddCSLuaFile()

ENT.Base = "terminator_nextbot"
DEFINE_BASECLASS(ENT.Base)

ENT.PrintName = "EXA Minion"
ENT.Spawnable = false

ENT.Models = { "models/player/combine_super_soldier.mdl" }
ENT.DefaultWeapon = "weapon_terminatorfists_term"

ENT.SpawnHealth = 250
ENT.FistDamageMul = 1.2
ENT.TERM_WEAPON_PROFICIENCY = WEAPON_PROFICIENCY_GOOD

ENT.WalkSpeed = 160
ENT.MoveSpeed = 300
ENT.RunSpeed  = 400
ENT.AccelerationSpeed = 1500

--------------------------------------------------
-- Server
--------------------------------------------------
if SERVER then

    function ENT:AdditionalInitialize()
        self:SetModel(self.Models[1])
        self:SetColor(Color(255, 255, 255, 150))
        self:SetMaterial("models/props_combine/stasisshield_sheet")
        self:SetRenderMode(RENDERMODE_TRANSALPHA)
        self:StartTrail()
        self:EmitSound("ambient/levels/labs/electric_explosion1.wav", 90)
    end

    function ENT:StartTrail()
        util.SpriteTrail(self, 0, Color(0, 255, 255, 200), false, 15, 0, 0.5, 1, "trails/laser.vmt")
    end

    function ENT:DoHardcodedRelations()
        self.term_HardCodedRelations = {
            ["player"] = { D_HT, D_HT, 1000 },
            ["npc_*"] = { D_HT, D_HT, 1000 },
            ["terminator_*"] = { D_HT, D_HT, 1000 },
            ["terminator_nextbot_exa"] = { D_LI, D_LI, 1000 },
            ["*"] = { D_HT, D_HT, 1000 }
        }
    end
end

--------------------------------------------------
-- Client
--------------------------------------------------
if CLIENT then
    language.Add("ent_exa_minion", "EXA Minion")
end