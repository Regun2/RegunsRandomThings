AddCSLuaFile()

ENT.Base = "terminator_nextbot_jerminator_realistic"
DEFINE_BASECLASS(ENT.Base)

ENT.PrintName = "The Almighty Jerma"
ENT.Spawnable = false

list.Set("NPC", "terminator_nextbot_almightyjerma", {
	Name = "The Almighty Jerma",
	Class = "terminator_nextbot_almightyjerma",
	AdminOnly = true,
	Category = "Terminator Nextbot",
})

if CLIENT then
	language.Add("terminator_nextbot_almightyjerma", ENT.PrintName)
	return
end

ENT.IsFodder        = false
ENT.CoroutineThresh = 0.002

ENT.term_SoundLevelShift = 20

ENT.WalkSpeed         = 750
ENT.MoveSpeed         = 2000
ENT.RunSpeed          = 3600
ENT.AccelerationSpeed = 5000
ENT.JumpHeight        = 140

ENT.FistDamageMul     = 10
ENT.ThrowingForceMul  = 10
ENT.SpawnHealth       = 2500000
ENT.MyPhysicsMass     = 150000

ENT.FootstepClomping      = true
ENT.TERM_WEAPON_PROFICIENCY = WEAPON_PROFICIENCY_PERFECT
ENT.duelEnemyTimeoutMul     = 8
ENT.DuelEnemyDist           = 5000
ENT.AlwaysAngry             = true
ENT.TermSoldier_Fearless    = true

function ENT:Initialize()
	BaseClass.Initialize(self)
	self:SetModelScale(10, 0)
end

function ENT:EnemyIsLethalInMelee()
	local enemy = self:GetEnemy()
	return IsValid(enemy) and self.IsSeeEnemy and enemy:GetClass() ~= "terminator_nextbot_almightyjerma"
end