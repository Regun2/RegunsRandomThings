AddCSLuaFile()

ENT.Base = "terminator_nextbot"
DEFINE_BASECLASS(ENT.Base)

ENT.PrintName = "Nightmare Clone"
ENT.Spawnable = false
ENT.Models = { "models/player/combine_super_soldier.mdl" }

ENT.DefaultWeapon = "weapon_nightmare_fists"
ENT.CanFindWeaponsOnTheGround = false
ENT.SpawnHealth = 100

ENT.WalkSpeed = 800
ENT.MoveSpeed = 1000
ENT.RunSpeed = 1200
ENT.AccelerationSpeed = 9999
ENT.JumpHeight = 200
ENT.FistDamageMul = 0

--------------------------------------------------
-- Server
--------------------------------------------------
if SERVER then

    function ENT:AdditionalInitialize()
        self:SetModel(self.Models[1])
        self:SetColor(Color(0, 0, 0))
        self:SetMaterial("models/shiny")
        self:SetRenderMode(RENDERMODE_TRANSALPHA)
        self:SetModelScale(1.1, 0)
        self:SetHealth(self.SpawnHealth)
        self:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
        self:StartTrail()
    end

    function ENT:StartTrail()
        util.SpriteTrail(self, 0, Color(0, 0, 0, 200), false, 20, 0, 0.6, 0.01, "trails/electric.vmt")
    end

    function ENT:Disintegrate()
        if self.HasDisintegrated then return end
        self.HasDisintegrated = true

        local fx = EffectData()
        fx:SetOrigin(self:GetPos())
        util.Effect("StunstickImpact", fx)

        self:EmitSound("ambient/levels/labs/electric_explosion2.wav", 100)
        SafeRemoveEntity(self)
    end

    function ENT:DoHardcodedRelations()
        self.term_HardCodedRelations = {
            ["player"] = { D_HT, D_HT, 1000 },
            ["npc_*"] = { D_HT, D_HT, 1000 },
            ["nextbot"] = { D_HT, D_HT, 1000 },
            ["terminator_*"] = { D_HT, D_HT, 1000 },
            ["*"] = { D_HT, D_HT, 1000 },
        }
    end

    function ENT:DoCustomTasks(defaultTasks)
        self.TaskList = {
            ["disintegrate_on_kill"] = {
                OnKillEnemy = function(self)
                    if not self.HasDisintegrated then
                        self:Disintegrate()
                    end
                end
            }
        }

        table.Merge(self.TaskList, defaultTasks or {})
    end

end

--------------------------------------------------
-- Client
--------------------------------------------------
if CLIENT then
    language.Add("ent_nightmare_clone", "Nightmare Clone")
end