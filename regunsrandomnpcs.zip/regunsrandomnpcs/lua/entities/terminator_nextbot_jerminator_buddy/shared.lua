AddCSLuaFile()

ENT.Base = "terminator_nextbot_jerminator"
DEFINE_BASECLASS(ENT.Base)

ENT.PrintName = "JermaBuddy"
ENT.Spawnable = false
ENT.BehaveInterval = 0.1

list.Set("NPC", "terminator_nextbot_jerminator_buddy", {
    Name = "JermaBuddy",
    Class = "terminator_nextbot_jerminator_buddy",
    Category = "Terminator Nextbot"
})

if CLIENT then
    language.Add("terminator_nextbot_jerminator_buddy", ENT.PrintName)
    return
end

-- CONFIG
local MODEL = "models/player/giwake/jermaregular.mdl"
ENT.Models = { MODEL }
ENT.ARNOLD_MODEL = MODEL

ENT.CanFindWeaponsOnTheGround = false
ENT.GetWeaponChanceScale = 0

ENT.TERM_FISTS = "weapon_jerminator_fists_buddy"
ENT.SpawnHealth = 125
ENT.FistDamageMul = 0
ENT.HealthRegen = 3
ENT.HealthRegenInterval = 0.5

ENT.term_SoundPitchShift = 0 -- No pitch shifting needed now
ENT.term_SoundLevelShift = 0

ENT.WalkSpeed = 80
ENT.MoveSpeed = 150
ENT.RunSpeed = 200

function ENT:AdditionalInitialize()
    self:SetModel(self.ARNOLD_MODEL)
    self:SetModelScale(0.9, 0)
    self:SetColor(Color(255, 255, 255))
    self:SetMaterial("")
    self.isTerminatorHunterChummy = "nil"
end

function ENT:DoHardcodedRelations()
    self.term_HardCodedRelations = {
        ["player"] = { D_LI, D_LI, 1000 },
        ["npc_citizen"] = { D_LI, D_LI, 1000 },
        ["exterminator_nextbot"] = { D_LI, D_LI, 1000 },
        ["terminator_nextbot_jerminator_friendly"] = { D_LI, D_LI, 1000 },
    }
end

-- Make npc_citizen friendly back to JermaBuddy
hook.Add("OnEntityCreated", "JermaBuddy_CitizenFriendly", function(ent)
    if ent:IsNPC() and ent:GetClass() == "npc_citizen" then
        timer.Simple(0, function()
            for _, jerma in ipairs(ents.FindByClass("terminator_nextbot_jerminator_buddy")) do
                if IsValid(jerma) then
                    ent:AddEntityRelationship(jerma, D_LI, 99)
                end
            end
        end)
    end
end)