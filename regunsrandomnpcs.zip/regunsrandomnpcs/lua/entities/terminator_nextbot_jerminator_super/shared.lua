AddCSLuaFile()

ENT.Base = "terminator_nextbot_jerminator"
DEFINE_BASECLASS(ENT.Base)

ENT.PrintName = "Jerma991"
ENT.Spawnable = false
ENT.BehaveInterval = 0.1

list.Set("NPC", "terminator_nextbot_jerminator_super", {
    Name = "Jerma991",
    Class = "terminator_nextbot_jerminator_super",
    Category = "Terminator Nextbot"
})

if CLIENT then
    language.Add("terminator_nextbot_jerminator_super", ENT.PrintName)

    -- 🟡 Halo Glow (client-side only)
    hook.Add("PreDrawHalos", "SuperJerma_Halo", function()
        local jermas = {}
        for _, ent in ipairs(ents.FindByClass("terminator_nextbot_jerminator_super")) do
            if IsValid(ent) then
                table.insert(jermas, ent)
            end
        end

        halo.Add(jermas, Color(255, 255, 0), 3, 3, 2, true, false)
    end)

    return
end

-- ========== Server-side Setup ==========

local MODEL = "models/player/giwake/jermaregular.mdl"

ENT.Models = { MODEL }
ENT.ARNOLD_MODEL = MODEL

ENT.TERM_FISTS = "weapon_jerminator_fists"
ENT.SpawnHealth = 3000
ENT.FistDamageMul = 3.0
ENT.HealthRegen = 6
ENT.HealthRegenInterval = 0.25

ENT.term_SoundPitchShift = -5
ENT.term_SoundLevelShift = 25

-- Speed multiplier
ENT.MoveSpeedMultiplier = 2 -- 2x speed

--------------------------------------------------
-- INITIALIZE
--------------------------------------------------
function ENT:Initialize()
    self.BehaveInterval = self.BehaveInterval or ENT.BehaveInterval or 0.1
    if BaseClass.Initialize then
        BaseClass.Initialize(self)
    end
end

function ENT:CommandNearbyJermas()
    for _, ent in ipairs(ents.FindInSphere(self:GetPos(), 1500)) do
        if not IsValid(ent) then continue end
        if ent == self then continue end
        if not ent:IsNPC() then continue end

        local class = ent:GetClass()
        local isJerma = (
            class == "terminator_nextbot_jerminator" or
            class == "terminator_nextbot_jerminator_scared" or
            class == "terminator_nextbot_jerminator_realistic"
        )

        if isJerma and not IsValid(ent:GetEnemy()) and not ent.InSuperJermaFollow then
            ent.InSuperJermaFollow = true

            if ent.StartTask2 then
                ent:KillAllTasksWith("movement")
                ent:StartTask2("movement_followentity", {
                    entity = self,
                    radius = 100
                }, "Following Super Jerma")
            end
        end
    end
end
--------------------------------------------------
-- Visuals & Fire Aura
--------------------------------------------------
function ENT:AdditionalInitialize()
    self:SetModel(self.ARNOLD_MODEL)
    self:SetColor(Color(255, 255, 0)) -- Yellow
    self:SetModelScale(1.25, 0)
    self:SetMaterial("")

    self.isTerminatorHunterChummy = "jerminator"
    self.superJermaTag = "superjerma_leader"

    self:AttachFireParticle()
end

function ENT:AttachFireParticle()
    if self.FireParticle then return end

    local particle = ents.Create("info_particle_system")
    if not IsValid(particle) then return end

    particle:SetKeyValue("effect_name", "env_fire_large")

    -- 🔥 Place below Jerma’s feet, centered
    local offset = Vector(0, 0, -10)

    particle:SetPos(self:GetPos() + offset)
    particle:SetParent(self)
    particle:SetOwner(self)
    particle:Spawn()
    particle:Activate()
    particle:Fire("Start", "", 0)

    self.FireParticle = particle
end

--------------------------------------------------
-- Apply Speed Multiplier to Locomotion
--------------------------------------------------
function ENT:RunBehaviour()
    -- Set movement speeds at runtime
    if self.loco then
        local curSpeed = self.loco:GetDesiredSpeed()
        if not self.OriginalSpeed then
            self.OriginalSpeed = curSpeed
        end
        self.loco:SetDesiredSpeed(self.OriginalSpeed * self.MoveSpeedMultiplier)
    end

    -- Call base AI control loop
    BaseClass.RunBehaviour(self)
end

--------------------------------------------------
-- Reuse Jerma Task System
--------------------------------------------------
function ENT:DoCustomTasks(defaultTasks)
    if scripted_ents.Get("terminator_nextbot_jerminator_realistic") then
        local jerma = scripted_ents.GetStored("terminator_nextbot_jerminator_realistic").t
        if jerma and jerma.DoCustomTasks then
            local baseTasks = {}
            jerma.DoCustomTasks(self, baseTasks)
            self.TaskList = table.Copy(baseTasks)
        end
    end

    self.TaskList = self.TaskList or {}

    -- Custom startup behavior
    self.TaskList["superjerma_intro"] = {
        StartsOnInitialize = true,
        OnCreated = function(self, data)
            self:Term_SpeakSoundNow("the_jerminator/anger/angry_jerma_1.wav")
        end
    }

    table.Merge(self.TaskList, defaultTasks)
end

function ENT:OnKilled(attacker, inflictor)
    for _, ent in ipairs(ents.FindByClass("npc_*")) do
        if ent.InSuperJermaFollow then
            ent.InSuperJermaFollow = nil
        end
    end
end