AddCSLuaFile()

ENT.Base = "ronald_nextbot"
DEFINE_BASECLASS("ronald_nextbot")
ENT.PrintName = "Donald Core"
ENT.Category = "Fun + Meme"
ENT.Spawnable = false

function ENT:Initialize()
    BaseClass.Initialize(self)

    self:SetSkin(0)
    self.SpawnHealth = 32
    self:SetHealth(self.SpawnHealth)

    if not self._isClone then
        self:SpawnClonesInCircle()
    end
end

function ENT:SpawnClonesInCircle()
    local center = self:GetPos()
    local radius = 100

    if not ents or not ents.Create then
        print("[Donald Core] WARNING: ents.Create is nil! Clones will NOT spawn.")
        return
    end

    for i = 1, 7 do
        local angle_deg = (360 / 7) * i
        local angle_rad = math.rad(angle_deg)
        local offset = Vector(math.cos(angle_rad), math.sin(angle_rad), 0) * radius
        local clonePos = center + offset + Vector(0, 0, 5)

        local clone = ents.Create("ronald_core")
        if IsValid(clone) then
            clone._isClone = true
            clone:SetPos(clonePos)
            clone:Spawn()
        else
            print("[Donald Core] Failed to spawn clone #" .. i)
        end
    end
end

if CLIENT then
    language.Add("ronald_core", "Donald Core")
end

list.Set("NPC", "ronald_core", {
    Name = "Donald Core",
    Class = "ronald_core",
    Category = "Terminator Nextbot"
})