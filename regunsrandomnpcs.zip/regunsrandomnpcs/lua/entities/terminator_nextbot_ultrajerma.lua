AddCSLuaFile()

ENT.Base = "terminator_nextbot_jerminator_realistic"
DEFINE_BASECLASS(ENT.Base)

ENT.PrintName = "Ultra Jerma"
ENT.Spawnable = false

list.Set("NPC", "terminator_nextbot_ultrajerma", {
    Name = "Ultra Jerma",
    Class = "terminator_nextbot_ultrajerma",
    AdminOnly = true,
    Category = "Terminator Nextbot"
})

if CLIENT then
    language.Add("terminator_nextbot_ultrajerma", ENT.PrintName)
    return
end

-- Boss Stats
ENT.IsFodder             = false
ENT.SpawnHealth          = 1750000
ENT.MyPhysicsMass        = 45000
ENT.FootstepClomping     = true
ENT.AlwaysAngry          = true
ENT.TermSoldier_Fearless = true
ENT.DuelEnemyDist        = 5000

ENT.WalkSpeed         = 800
ENT.MoveSpeed         = 2400
ENT.RunSpeed          = 4000
ENT.AccelerationSpeed = 6000
ENT.JumpHeight        = 300

ENT.FistDamageMul     = 12
ENT.ThrowingForceMul  = 10

ENT.TERM_WEAPON_PROFICIENCY = WEAPON_PROFICIENCY_PERFECT

function ENT:Initialize()
    BaseClass.Initialize(self)
    self.OrbitingBalls = {}

    for i = 1, 3 do
        local ball = ents.Create("prop_combine_ball")
        if not IsValid(ball) then continue end

        ball:SetModel("models/Effects/combineball.mdl")
        ball:SetModelScale(0.25, 0)
        ball:SetPos(self:GetPos())
        ball:SetOwner(self)
        ball:Spawn()
        ball:SetMoveType(MOVETYPE_NOCLIP)
        ball:SetCollisionGroup(COLLISION_GROUP_IN_VEHICLE)
        ball:SetNotSolid(true)

        local phys = ball:GetPhysicsObject()
        if IsValid(phys) then
            phys:EnableGravity(false)
            phys:EnableCollisions(false)
        end

        -- Glow sprite
        local sprite = ents.Create("env_sprite")
        if IsValid(sprite) then
            sprite:SetKeyValue("model", "effects/ar2_altfire1.vmt")
            sprite:SetKeyValue("scale", "0.15")
            sprite:SetKeyValue("rendercolor", "255 255 255")
            sprite:SetKeyValue("rendermode", "5")
            sprite:SetPos(ball:GetPos())
            sprite:SetParent(ball)
            sprite:SetOwner(self)
            sprite:Spawn()
            sprite:Activate()
        end

        -- Tilt offset based on index
        local tilt = Angle(0, 0, 0)
        if i == 2 then tilt = Angle(45, 0, 0)
        elseif i == 3 then tilt = Angle(-45, 0, 0) end

        table.insert(self.OrbitingBalls, {
            entity = ball,
            sprite = sprite,
            angleOffset = (360 / 3) * i,
            tilt = tilt,
            lastAttackTime = 0
        })
    end

    self:StartOrbitingBalls()
end

function ENT:StartOrbitingBalls()
    local id = "UltraJermaOrbit_" .. self:EntIndex()
    local orbitHeightOffset = Vector(0, 0, 50)
    local orbitRadius = 30
    local orbitSpeed = 1000

    local function EnsureBallExists(index, data)
        if not IsValid(data.entity) then
            local newBall = ents.Create("prop_combine_ball")
            newBall:SetModel("models/Effects/combineball.mdl")
            newBall:SetModelScale(0.25, 0)
            newBall:SetPos(self:GetPos())
            newBall:SetOwner(self)
            newBall:Spawn()
            newBall:SetMoveType(MOVETYPE_NOCLIP)
            newBall:SetCollisionGroup(COLLISION_GROUP_IN_VEHICLE)
            newBall:SetNotSolid(true)

            local phys = newBall:GetPhysicsObject()
            if IsValid(phys) then
                phys:EnableGravity(false)
                phys:EnableCollisions(false)
            end
            data.entity = newBall
        end

        if not IsValid(data.sprite) then
            local sprite = ents.Create("env_sprite")
            if IsValid(sprite) then
                sprite:SetKeyValue("model", "effects/ar2_altfire1.vmt")
                sprite:SetKeyValue("scale", "0.15")
                sprite:SetKeyValue("rendercolor", "255 255 255")
                sprite:SetKeyValue("rendermode", "5")
                sprite:SetPos(data.entity:GetPos())
                sprite:SetParent(data.entity)
                sprite:SetOwner(self)
                sprite:Spawn()
                sprite:Activate()
                data.sprite = sprite
            end
        end
    end

    timer.Create(id, 0.01, 0, function()
        if not IsValid(self) then timer.Remove(id) return end

        for i, data in ipairs(self.OrbitingBalls) do
            EnsureBallExists(i, data)

            local ball = data.entity
            if not IsValid(ball) then continue end

            local angle = data.angleOffset + (CurTime() * orbitSpeed)
            local relativePos = Angle(0, angle, 0):Forward()

            if data.tilt and data.tilt != Angle(0, 0, 0) then
                relativePos:Rotate(data.tilt)
            end

            relativePos = relativePos * orbitRadius
            local worldOffset = self:GetRight() * relativePos.x +
                                self:GetForward() * relativePos.y +
                                self:GetUp() * relativePos.z
            local orbitPos = self:GetPos() + orbitHeightOffset + worldOffset
            ball:SetPos(orbitPos)

            -- Damage nearby enemies
            for _, ent in ipairs(ents.FindInSphere(ball:GetPos(), 40)) do
                if ent ~= self and ent ~= ball and (ent:IsNPC() or ent:IsPlayer()) then
                    if CurTime() >= (data.lastAttackTime or 0) + 0.5 then
                        local dmg = DamageInfo()
                        dmg:SetAttacker(self)
                        dmg:SetInflictor(ball)
                        dmg:SetDamageType(DMG_DISSOLVE)
                        dmg:SetDamage(50)
                        ent:TakeDamageInfo(dmg)
                        data.lastAttackTime = CurTime()
                    end
                end
            end
        end
    end)
end
function ENT:OnRemove()
    timer.Remove("UltraJermaOrbit_" .. self:EntIndex())
    for _, data in ipairs(self.OrbitingBalls or {}) do
        if IsValid(data.entity) then data.entity:Remove() end
        if IsValid(data.sprite) then data.sprite:Remove() end
    end
end