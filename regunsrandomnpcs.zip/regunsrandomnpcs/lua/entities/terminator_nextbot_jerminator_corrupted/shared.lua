AddCSLuaFile()

ENT.Base = "terminator_nextbot_jerminator"
DEFINE_BASECLASS(ENT.Base)
ENT.PrintName = "Jerma???"
ENT.Spawnable = false

local hasTerminator = file.Exists("lua/entities/terminator_nextbot/shared.lua", "GAME")
local hasJerminator = file.Exists("lua/entities/terminator_nextbot_jerminator_realistic/shared.lua", "GAME")

if hasTerminator and hasJerminator then
    list.Set("NPC", "terminator_nextbot_jerminator_corrupted", {
        Name = "Jerma?",
        Class = "terminator_nextbot_jerminator_corrupted",
        Category = "Terminator Nextbot"
    })
end

if CLIENT then
    language.Add("terminator_nextbot_jerminator_corrupted", "Jerma???")
    return
end

local JERMA_MODEL = "models/player/giwake/jermaregular.mdl"
ENT.Models = { JERMA_MODEL }

ENT.TERM_FISTS = "weapon_jerminator_fists"
ENT.term_SoundPitchShift = -15
ENT.term_SoundLevelShift = 20
ENT.CanSpeak = true
ENT.NextTermSpeak = 0

ENT.FistDamageMul = 1.25
ENT.SpawnHealth = 1500
ENT.HealthRegen = 2
ENT.HealthRegenInterval = 0.5

ENT.MetallicMoveSounds = false
ENT.DoMetallicDamage = false
ENT.CanSwim = true
ENT.BreathesAir = true

function ENT:AdditionalInitialize()
    self:SetMaterial("")
    self:SetColor(Color(255, 255, 255))
    self:SetModelScale(1, 0)

    self.originalSpeed = 300
    self.originalDamage = self.FistDamageMul
    self.transformed = false
end

function ENT:Think()
    if self.transformed then
        -- Constantly enforce corrupted appearance
        if self:GetMaterial() ~= "models/debug/debugwhite" then
            self:SetMaterial("models/debug/debugwhite")
        end
        if self:GetColor() ~= Color(0, 0, 0) then
            self:SetColor(Color(0, 0, 0))
        end
    elseif self:Health() <= self:GetMaxHealth() * 0.3 and not self.transformed then
        self:TriggerCorruption()
    end

    if BaseClass.Think then BaseClass.Think(self) end
    self:NextThink(CurTime())
    return true
end

function ENT:TriggerCorruption()
    if self.transformed then return end
    self.transformed = true

    self:SetMaterial("models/debug/debugwhite")
    self:SetColor(Color(0, 0, 0))
    self:SetModelScale(1.3, 1.5)

    self.FistDamageMul = self.originalDamage * 3 -- 3× melee damage
    self.RunSpeed = self.originalSpeed * 2       -- 2× speed
    self.WalkSpeed = self.originalSpeed * 1.5

    self:EmitSound("npc/overwatch/radiovoice/prepareforfinalattack.wav", 90, 50)
    self:Term_SpeakSoundNow("the_jerminator/anger/angry1.ogg", -15)

    if SERVER then
        local eff = EffectData()
        eff:SetOrigin(self:GetPos() + Vector(0, 0, 50))
        util.Effect("Explosion", eff, true, true)
    end
end

function ENT:jerm_SpeakARandomSound(directory)
    local inDir = jermSounds and jermSounds[directory]
    if not inDir or #inDir == 0 then return end

    local randSnd = inDir[math.random(1, #inDir)]
    self:Term_SpeakSound(randSnd, 0.85)
end

-- Maintain black appearance if weapon changes
function ENT:OnGivenWeapon(wep)
    if self.transformed then
        timer.Simple(0.1, function()
            if IsValid(self) then
                self:SetMaterial("models/debug/debugwhite")
                self:SetColor(Color(0, 0, 0))
            end
        end)
    end
end

-- Spawn 4 Shadow Jermas on death
function ENT:OnKilled(_, _, _)
    local pos = self:GetPos()
    for i = 1, 4 do
        local offset = VectorRand() * 100
        local spawnPos = pos + Vector(0, 0, 20) + offset

        local ent = ents.Create("terminator_nextbot_jerminator_shadow")
        if IsValid(ent) then
            ent:SetPos(spawnPos)
            ent:Spawn()
        end
    end
end

function ENT:DoCustomTasks(defaultTasks)
    self.TaskList = {
        ["corrupted_handler"] = {
            StartsOnInitialize = true,
            OnCreated = function(self)
                self:Term_SpeakSoundNow("the_jerminator/spawned/spawn0.ogg", -15)
            end,
            OnDamaged = function(self, _, dmg)
                if dmg:GetDamage() > 30 then
                    self:Term_SpeakSoundNow("the_jerminator/pain/pain1.ogg", -15)
                end
            end,
            OnKilled = function(self, _, _, ragdoll)
                if IsValid(ragdoll) then
                    ragdoll:SetMaterial("models/debug/debugwhite")
                    ragdoll:SetColor(Color(0, 0, 0))
                end
            end,
        }
    }
    table.Merge(self.TaskList, defaultTasks or {})
end