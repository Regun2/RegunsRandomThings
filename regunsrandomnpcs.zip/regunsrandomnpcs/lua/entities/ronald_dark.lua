AddCSLuaFile()

ENT.Base = "ronald_nextbot"
DEFINE_BASECLASS("ronald_nextbot")

ENT.PrintName = "Dark Donald"
ENT.Category = "Fun + Meme"
ENT.Spawnable = false

function ENT:Initialize()
	BaseClass.Initialize(self)	

	self:SetSkin(4)

	self.SpawnHealth = 250
	self:SetHealth(self.SpawnHealth)

	self.WalkSpeed = 280
	self.MoveSpeed = 360
	self.RunSpeed = 640
	self.AccelerationSpeed = 3200

	self.SpecialCooldowns = self.SpecialCooldowns or {}
	self:ScaleCooldowns(0.4)
end

function ENT:ScaleCooldowns(scale)
	for key, move in pairs(self.SpecialMoves or {}) do
		if move.Cooldown then
			move.Cooldown = math.max(0.2, move.Cooldown * scale)
		end
	end
end

function ENT:Think()
	if self.SetHealth and self.GetHealth and self:GetHealth() < self.SpawnHealth then
		self:SetHealth(math.min(self:GetHealth() + 1, self.SpawnHealth))
	end

	return BaseClass.Think(self)
end

-- Overrides for projectile visuals
hook.Add("OnEntityCreated", "DarkDonald_DarkenProjectiles", function(ent)
	if not IsValid(ent) or ent:GetClass() ~= "prop_physics" then return end
	local owner = ent:GetOwner()
	if not IsValid(owner) then return end
	if owner:GetClass() ~= "ronald_dark" then return end

	timer.Simple(0, function()
		if not IsValid(ent) then return end
		ent:SetColor(Color(50, 50, 50))
		ent:SetMaterial("models/debug/debugwhite")
	end)
end)

-- Trail override for burger
hook.Add("EntityFireBullets", "DarkDonaldFixBurgerTrail", function(ent, data)
	if ent:GetClass() == "ronald_dark" then
		data.TracerName = "gray"
	end
end)

-- Make McLaser gray
hook.Add("PostDrawTranslucentRenderables", "DarkDonaldMcLaserColor", function()
	for _, v in ipairs(ents.FindByClass("ronald_dark")) do
		-- future logic to tint effects if McLaser custom effect added
	end
end)

if CLIENT then
	language.Add("ronald_dark", "Dark Donald")
end

list.Set("NPC", "ronald_dark", {
	Name = "Dark Donald",
	Class = "ronald_dark",
	Category = "Terminator Nextbot"
})